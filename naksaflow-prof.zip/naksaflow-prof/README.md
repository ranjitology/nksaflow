# NaksaFlow Pro

Smart Municipality Approval & Building Permit Tracking System.

See **[SETUP.md](./SETUP.md)** for install steps, demo accounts, and what's
included in this Phase 1 build.
