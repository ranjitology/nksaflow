/* eslint-disable no-console */
const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding NaksaFlow Pro demo data…");

  const passwordHash = await bcrypt.hash("password123", 10);

  // ---- Company settings ----
  await prisma.companySetting.upsert({
    where: { id: "singleton" },
    update: {},
    create: {
      id: "singleton",
      companyName: "Himalayan Design Consultancy",
      address: "Putalisadak, Kathmandu",
      phone: "01-4123456",
      email: "info@himalayandesign.com.np",
      panNumber: "301234567",
      engineerLicenseNo: "NEC-4521",
    },
  });

  // ---- Users ----
  const admin = await prisma.user.upsert({
    where: { email: "admin@naksaflow.com" },
    update: {},
    create: {
      name: "Sunita Shrestha",
      email: "admin@naksaflow.com",
      passwordHash,
      role: "ADMIN",
      phone: "9801234567",
      licenseNumber: "NEC-1001",
    },
  });

  const engineer = await prisma.user.upsert({
    where: { email: "engineer@naksaflow.com" },
    update: {},
    create: {
      name: "Bikash Tamang",
      email: "engineer@naksaflow.com",
      passwordHash,
      role: "ENGINEER",
      phone: "9812345678",
      licenseNumber: "NEC-2045",
    },
  });

  const staff = await prisma.user.upsert({
    where: { email: "staff@naksaflow.com" },
    update: {},
    create: {
      name: "Anita Gurung",
      email: "staff@naksaflow.com",
      passwordHash,
      role: "STAFF",
      phone: "9823456789",
    },
  });

  // ---- Municipalities ----
  const municipalityData = [
    { name: "Kathmandu Metropolitan City", contactPerson: "Er. Ram Bahadur", contactPhone: "01-4441234", standardFee: 15000 },
    { name: "Lalitpur Metropolitan City", contactPerson: "Er. Shyam Poudel", contactPhone: "01-5551234", standardFee: 12000 },
    { name: "Bhaktapur Municipality", contactPerson: "Er. Krishna Maharjan", contactPhone: "01-6612345", standardFee: 10000 },
    { name: "Madhyapur Thimi Municipality", contactPerson: "Er. Gopal Shakya", contactPhone: "01-6634567", standardFee: 9000 },
    { name: "Budhanilkantha Municipality", contactPerson: "Er. Sarita Basnet", contactPhone: "01-4890123", standardFee: 8500 },
  ];
  const municipalities = [];
  for (const m of municipalityData) {
    municipalities.push(
      await prisma.municipality.upsert({ where: { name: m.name }, update: {}, create: m })
    );
  }

  // ---- Clients ----
  const clientData = [
    { fullName: "Ramesh Khadka", phone: "9841112233", email: "ramesh.k@example.com", citizenshipNumber: "12-01-70-01234", panNumber: "600011122", wardNumber: "4" },
    { fullName: "Sabina Rai", phone: "9851223344", email: "sabina.rai@example.com", citizenshipNumber: "27-01-69-05678", panNumber: "600022233", wardNumber: "9" },
    { fullName: "Prakash Adhikari", phone: "9861334455", email: "prakash.a@example.com", citizenshipNumber: "42-01-72-09988", panNumber: "600033344", wardNumber: "2" },
    { fullName: "Nirmala Thapa", phone: "9871445566", email: "nirmala.t@example.com", citizenshipNumber: "05-01-68-04455", panNumber: "600044455", wardNumber: "11" },
  ];
  const clients = [];
  for (let i = 0; i < clientData.length; i++) {
    const c = clientData[i];
    let client = await prisma.client.findFirst({ where: { phone: c.phone } });
    if (!client) {
      client = await prisma.client.create({
        data: { ...c, municipalityId: municipalities[i % municipalities.length].id },
      });
    }
    clients.push(client);
  }

  // Link a demo CLIENT-role user to the first client for portal login
  await prisma.user.upsert({
    where: { email: "client@naksaflow.com" },
    update: { clientId: clients[0].id },
    create: {
      name: clients[0].fullName,
      email: "client@naksaflow.com",
      passwordHash,
      role: "CLIENT",
      phone: clients[0].phone,
      clientId: clients[0].id,
    },
  });

  // ---- Projects across different stages ----
  const stagesToSeed = [
    "NEW_INQUIRY",
    "SITE_SURVEY",
    "ARCHITECTURAL_DRAWING",
    "MUNICIPALITY_SUBMISSION",
    "UNDER_REVIEW",
    "CORRECTION_REQUIRED",
    "APPROVED",
    "COMPLETED",
  ];

  const existingCount = await prisma.naksaProject.count();
  if (existingCount === 0) {
    let seq = 1;
    const year = new Date().getFullYear();

    for (let i = 0; i < stagesToSeed.length; i++) {
      const stage = stagesToSeed[i];
      const client = clients[i % clients.length];
      const municipality = municipalities[i % municipalities.length];
      const projectNumber = `NFP-${year}-${String(seq++).padStart(5, "0")}`;

      const project = await prisma.naksaProject.create({
        data: {
          projectNumber,
          clientId: client.id,
          municipalityId: municipality.id,
          wardNumber: client.wardNumber || "5",
          kittaNumber: `${100 + i}/b`,
          landArea: 4 + i * 0.5,
          landAreaUnit: "Ropani",
          buildingType: ["RESIDENTIAL", "COMMERCIAL", "MIXED_USE"][i % 3],
          numberOfFloors: 2 + (i % 4),
          estimatedCost: 2500000 + i * 450000,
          stage,
          progressPercent: Math.round((i / (stagesToSeed.length - 1)) * 100),
          engineerId: engineer.id,
          surveyorId: engineer.id,
          createdById: admin.id,
          startDate: new Date(Date.now() - (30 + i * 10) * 24 * 60 * 60 * 1000),
          submissionDate: i >= 3 ? new Date(Date.now() - (20 - i) * 24 * 60 * 60 * 1000) : null,
          approvalDate: stage === "APPROVED" || stage === "COMPLETED" ? new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) : null,
          completionDate: stage === "COMPLETED" ? new Date() : null,
          statusHistory: {
            create: { stage, note: "Seeded demo record" },
          },
        },
      });

      // Payments per project
      await prisma.payment.create({
        data: {
          projectId: project.id,
          clientId: client.id,
          type: "CONSULTANCY_FEE",
          amount: 50000 + i * 5000,
          method: "BANK_TRANSFER",
          status: i % 2 === 0 ? "PAID" : "PENDING",
          paidAt: i % 2 === 0 ? new Date() : null,
        },
      });
      await prisma.payment.create({
        data: {
          projectId: project.id,
          clientId: client.id,
          type: "MUNICIPALITY_FEE",
          amount: municipality.standardFee,
          method: "CASH",
          status: stage === "APPROVED" || stage === "COMPLETED" ? "PAID" : "PENDING",
          paidAt: stage === "APPROVED" || stage === "COMPLETED" ? new Date() : null,
        },
      });
      // A drawing revision + site survey on the first seeded project, so the
      // new Phase 3 modules aren't empty on first login.
      if (i === 0) {
        await prisma.drawingRevision.create({
          data: {
            projectId: project.id,
            revisionNumber: 1,
            revisionDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
            revisionReason: "Adjusted front setback per ward guideline",
            engineerNotes: "Reduced front setback intrusion by 0.6m to match ward bylaw.",
            engineerId: engineer.id,
          },
        });
        await prisma.siteSurvey.create({
          data: {
            projectId: project.id,
            surveyDate: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000),
            engineerId: engineer.id,
            gpsLatitude: 27.7172,
            gpsLongitude: 85.324,
            siteNotes: "Flat plot, road access on the north side. No encroachment observed.",
          },
        });
      }
    }
  }

  // ---- Demo notifications for the admin account ----
  const firstProject = await prisma.naksaProject.findFirst({ orderBy: { createdAt: "asc" } });
  if (firstProject) {
    const existingNotifications = await prisma.notification.count({ where: { userId: admin.id } });
    if (existingNotifications === 0) {
      await prisma.notification.createMany({
        data: [
          {
            userId: admin.id,
            projectId: firstProject.id,
            type: "PROJECT_CREATED",
            title: `New project — ${firstProject.projectNumber}`,
            message: "A new Naksa Pass file was opened.",
          },
          {
            userId: admin.id,
            projectId: firstProject.id,
            type: "PAYMENT_DUE",
            title: `Payment due — ${firstProject.projectNumber}`,
            message: "A consultancy fee is still outstanding.",
          },
        ],
      });
    }
  }

  console.log("Seed complete.");
  console.log("Login with: admin@naksaflow.com / engineer@naksaflow.com / staff@naksaflow.com / client@naksaflow.com");
  console.log("Password for all demo accounts: password123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
