# NaksaFlow Pro — Phase 1 (Foundation)

Smart Municipality Naksa Pass Tracker System — Next.js 15 + Prisma + SQLite.

## What's in this phase

- Full Prisma schema for every module in the spec (Users, Clients, Municipalities,
  Projects, Status History, Documents, Drawing Revisions, Site Surveys, Payments,
  Invoices, Notifications, Activity Log, Company Settings).
- Credentials auth (NextAuth v5) with 4 roles: Admin, Engineer, Staff, Client —
  route-level RBAC via middleware.
- Dashboard: live stat cards, revenue cards, 4 charts (monthly submissions,
  approval success rate, municipality-wise, revenue), recent projects.
- Projects module: table view + drag-and-drop Kanban across all 11 workflow
  stages, create form, detail page with approval timeline, stage updater,
  and document upload (PDF/DWG/DXF/JPG/PNG to local disk).
- Clients & Municipalities: list + quick-add.
- Client Portal (`/portal`): a client-role login sees their own project status,
  timeline, and documents.
- Dark mode / light mode toggle.

Documents, Payments, Reports, Users, and Settings pages are present in the nav
and route to a "coming soon" placeholder — the database schema already supports
them; the UI lands in the next phase.

## ⚠️ One important note on where this was built

# NaksaFlow Pro — Phase 1 + 2 + 3 + 4 + 5

Smart Municipality Naksa Pass Tracker System — Next.js 15 + Prisma + SQLite.

## What's in this build

**Foundation (Phase 1)**
- Full Prisma schema for every module in the spec (Users, Clients, Municipalities,
  Projects, Status History, Documents, Drawing Revisions, Site Surveys, Payments,
  Invoices, Notifications, Activity Log, Company Settings).
- Credentials auth (NextAuth v5) with 4 roles: Admin, Engineer, Staff, Client —
  route-level RBAC via middleware (split edge-safe config + full Prisma-backed config).
- Dashboard: live stat cards, revenue cards, 4 charts (monthly submissions,
  approval success rate, municipality-wise, revenue), recent projects.
- Projects module: table view + drag-and-drop Kanban across all 11 workflow
  stages, create form, detail page with approval timeline, stage updater,
  and document upload (PDF/DWG/DXF/JPG/PNG to local disk).
- Clients & Municipalities: list + quick-add.
- Client Portal (`/portal`): a client-role login sees their own project status,
  timeline, and documents.
- Dark mode / light mode toggle.

**Phase 2**
- **Company Settings**: name, address, PAN, engineer license, and logo/signature/
  stamp image uploads — used as the letterhead on generated PDFs.
- **Users**: Admin-only user management — create Admin/Engineer/Staff accounts,
  activate/deactivate.
- **Payments**: record consultancy/municipality/advance/due payments per project,
  filter by status, running totals — with one-click **Invoice PDF** and
  **Receipt PDF** generation (jsPDF, stamped with your company letterhead).
- **Document Library**: a searchable, filterable view across every project's
  uploaded drawings and certificates (not just per-project).
- **Reports**: a hub with 6 report types — Project Report (PDF), Municipality,
  Engineer Performance, Monthly Approval, Revenue, and Pending Projects
  (all Excel via SheetJS).

**Phase 3**
- **Site Survey module**: log a survey per project with date, engineer, GPS
  coordinates (manual entry or "use my current location" via the browser's
  Geolocation API), site notes, and photo uploads — plus a one-click **Survey
  Report PDF**.
- **Drawing Revision history**: log numbered revisions with reason, engineer
  notes, and an optional revised-drawing file; a lightweight **compare view**
  lets you select any two revisions and see them side by side.
- **In-app notifications**: real notifications — fired on project creation,
  stage changes (with special handling for Correction Required and Approved),
  and payments recorded as pending/overdue. The bell in the top bar shows an
  unread count, polls every 30s, and lets you mark individual items or
  everything as read.

**Phase 4 — added in this pass**
- **Email notifications**: every in-app notification now also sends an email
  to the recipient, using `nodemailer`. If `SMTP_HOST`/`SMTP_USER`/`SMTP_PASS`
  aren't set in `.env`, emails are logged to the console instead of sent —
  the app works fully either way, so you can wire up real SMTP whenever you're
  ready (see `.env.example`).
- **Global search**: a real ⌘K / Ctrl+K command palette, reachable from the
  search bar in the top bar, searching across Projects, Clients, and
  Municipalities in one query with grouped, clickable results.
- **Activity Log viewer**: a new Admin-only page (`/activity`) showing the
  full audit trail — who did what, in which module, on which project — with
  search and a module filter. The underlying log has been recorded since
  Phase 1; this is the first UI to view it.

That completes every module named in the original spec. Two things remain
intentionally lighter-weight than a "real" production system: the Excel/PDF
report generation runs client-side (no server-side file archive of past
reports), and email delivery has no retry queue — a failed send is logged,
not retried.

**Phase 5 — added in this pass**
- **Bulk actions on the Projects table**: select any rows via checkbox
  (including "select all"), then either move them all to a new stage in one
  action, or export the selection (or the whole filtered list, if nothing's
  selected) straight to Excel.
- **Client portal payment downloads**: clients can now download their own
  Invoice/Receipt PDFs directly from `/portal`, not just see totals. This
  required opening two specific API routes (`/api/payments/*/invoice` and
  `/api/settings`) to the CLIENT role — the invoice route double-checks that
  the payment actually belongs to that client's own record before generating
  anything, so one client can't fetch another's documents by guessing an ID.

## ⚠️ One important note on where this was built

This was built in a sandboxed environment without general internet access, so
I could not run `npx prisma generate` or start the dev server here to test it
live (Prisma needs to download a query-engine binary from `binaries.prisma.sh`,
which wasn't reachable). I did run ESLint across the whole `src/` tree after
every phase and it's clean, but you'll want to run through setup once on your
machine to catch anything I can't see from here — particularly the jsPDF
logo/signature/stamp image embedding, the browser Geolocation prompt, and
actual SMTP delivery (untestable without a real mail server), all of which I
couldn't verify visually or at runtime.

## Setup

```bash
cd naksaflow-pro
npm install              # also runs `prisma generate` via postinstall
npx prisma migrate dev --name init   # creates prisma/dev.db and applies the schema
npm run db:seed          # seeds demo users, clients, municipalities, projects
npm run dev
```

Open http://localhost:3000 — you'll be redirected to `/login`.

### Demo accounts (password for all: `password123`)

| Role     | Email                    |
|----------|--------------------------|
| Admin    | admin@naksaflow.com      |
| Engineer | engineer@naksaflow.com   |
| Staff    | staff@naksaflow.com      |
| Client   | client@naksaflow.com     |

The Client account is pre-linked to a seeded client record, so it lands on
`/portal` with real project data instead of an empty state. The admin account
already has two demo notifications waiting in the bell icon, and the first
seeded project already has one drawing revision and one site survey logged.

Without SMTP configured, watch your terminal running `npm run dev` — every
notification email will print there as `[email:not-configured] To: ... |
Subject: ... | ...` instead of actually sending.

## Environment variables

Copy `.env.example` to `.env` (already present with working defaults for local
dev) — no changes are required to run locally. For production, replace
`NEXTAUTH_SECRET` with a long random string, e.g. `openssl rand -base64 32`,
and fill in `SMTP_HOST` / `SMTP_USER` / `SMTP_PASS` / `SMTP_FROM` if you want
real notification emails.

## Project structure

```
src/
  app/
    login/                 # public login page
    (app)/                 # staff-side shell (sidebar + topbar), role-guarded
      dashboard/
      projects/            # list (table/kanban), new, [id] detail
      clients/  municipalities/
      documents/            # global document library
      payments/             # payment ledger + invoice/receipt PDF
      reports/              # 6 report types, PDF/Excel export
      activity/             # admin-only audit trail viewer
      users/                # admin user management
      settings/             # company profile + logo/signature/stamp
    portal/                 # client-only shell + status view
    api/
      auth/[...nextauth]/
      projects/  clients/  municipalities/  users/
      payments/  settings/  reports/  notifications/  search/
      projects/[id]/surveys/  projects/[id]/revisions/
  components/
    layout/                 # sidebar, topbar
    dashboard/              # stat cards, recharts wrappers
    projects/               # table, kanban, form, timeline, stage updater,
                             # docs, site-survey-manager, drawing-revisions
    clients/ municipalities/ documents/ payments/ users/ settings/ reports/
    activity/               # audit trail table
    notifications/          # notification bell dropdown
    search/                 # ⌘K global search command palette
    ui/                     # modal, coming-soon
  lib/
    auth.config.js          # edge-safe NextAuth config (used by middleware)
    auth.js                 # full NextAuth config with Credentials + Prisma
    prisma.js  rbac.js  stages.js  utils.js  project-helpers.js
    notifications.js        # notification fan-out helpers (in-app + email)
    email.js                # nodemailer wrapper, no-ops without SMTP config
    validations/project.js
    reports/pdf.js           # jsPDF invoice/receipt/project/survey report generators
    reports/excel.js         # SheetJS export helper
  middleware.js             # route-level RBAC guard
prisma/
  schema.prisma
  seed.js
```

## Design direction

The visual language leans into the "engineering approval office" rather than a
generic SaaS template: a blueprint-navy/brass palette, a faint blueprint grid
on key surfaces, corner registration ticks on stat cards, and a rotated-seal
"stamp" motif for Approved/Completed status badges. Fonts: Space Grotesk
(display), Inter (body), JetBrains Mono (project numbers, dates, currency).

## Ideas for a Phase 6 (not built)

1. Server-side report archive (store generated PDFs/Excel files, not just
   stream them to the browser)
2. Email delivery retry queue / dead-letter handling

