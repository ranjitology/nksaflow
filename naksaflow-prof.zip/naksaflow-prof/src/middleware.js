import NextAuth from "next-auth";
import { authConfig } from "@/lib/auth.config";

// A separate, edge-safe NextAuth instance built from the shared config.
// It has no providers (so no Prisma/bcrypt), which keeps it runnable
// inside the Edge middleware runtime. Route authorization is entirely
// driven by the `authorized` callback in auth.config.js.
export const { auth } = NextAuth(authConfig);

export default auth((req) => {
  // NextAuth's `authorized` callback (see auth.config.js) already decides
  // true/false. When it returns false, NextAuth issues its own redirect to
  // the sign-in page. We only need custom logic for the CLIENT-role fallback.
  const { pathname } = req.nextUrl;
  const role = req.auth?.user?.role;

  if (role === "CLIENT" && !pathname.startsWith("/portal") && !pathname.startsWith("/api/auth")) {
    return Response.redirect(new URL("/portal", req.url));
  }
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|uploads).*)"],
};
