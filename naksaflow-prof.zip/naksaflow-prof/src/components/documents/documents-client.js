"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search, FileText, Download } from "lucide-react";
import { formatDateTime, humanizeEnum } from "@/lib/utils";

const CATEGORIES = [
  "ARCHITECTURAL_DRAWING",
  "STRUCTURAL_DRAWING",
  "OWNERSHIP_CERTIFICATE",
  "CITIZENSHIP",
  "TAX_CLEARANCE",
  "MUNICIPALITY_DOCUMENT",
  "SURVEY_REPORT",
  "SITE_PHOTO",
  "OTHER",
];

export default function DocumentsClient({ documents }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("");

  const filtered = useMemo(() => {
    return documents.filter((d) => {
      if (category && d.category !== category) return false;
      if (query && !d.fileName.toLowerCase().includes(query.toLowerCase()) && !d.project.projectNumber.toLowerCase().includes(query.toLowerCase())) {
        return false;
      }
      return true;
    });
  }, [documents, query, category]);

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div>
        <h1 className="font-display text-xl font-semibold">Document Library</h1>
        <p className="text-sm text-foreground/55 mt-0.5">
          Every drawing and certificate across every project, in one folder view.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[220px] max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search file name or project no..."
            className="w-full rounded-lg border border-border bg-surface pl-8 pr-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30 focus:border-ink-500 transition"
          />
        </div>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-lg border border-border bg-surface px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30"
        >
          <option value="">All categories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {humanizeEnum(c)}
            </option>
          ))}
        </select>
      </div>

      <div className="card-surface overflow-hidden">
        {filtered.length === 0 ? (
          <p className="text-sm text-foreground/45 text-center py-12">No documents match your filters.</p>
        ) : (
          <div className="divide-y divide-border">
            {filtered.map((d) => (
              <a
                key={d.id}
                href={d.fileUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between px-4 py-3 hover:bg-surface-2/60 transition"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <FileText size={16} className="text-ink-600 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-medium truncate">{d.fileName}</p>
                    <p className="text-[11.5px] text-foreground/45">
                      <Link
                        href={`/projects/${d.project.id}`}
                        onClick={(e) => e.stopPropagation()}
                        className="font-tabular text-ink-600 hover:underline"
                      >
                        {d.project.projectNumber}
                      </Link>
                      {" · "}
                      {humanizeEnum(d.category)} · {d.uploadedBy?.name || "Unknown"} · {formatDateTime(d.createdAt)}
                    </p>
                  </div>
                </div>
                <Download size={14} className="text-foreground/35 shrink-0 ml-2" />
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
