"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { Loader2, Save, Image as ImageIcon, PenTool, Stamp as StampIcon } from "lucide-react";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

function ImageSlot({ label, icon: Icon, currentUrl, onFileSelected }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label}</label>
      <div className="flex items-center gap-3">
        <div className="w-16 h-16 rounded-lg border border-border bg-surface-2 flex items-center justify-center overflow-hidden shrink-0">
          {currentUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={currentUrl} alt={label} className="w-full h-full object-contain" />
          ) : (
            <Icon size={18} className="text-foreground/30" />
          )}
        </div>
        <label className="text-xs font-medium text-ink-600 hover:text-ink-800 cursor-pointer border border-border rounded-lg px-3 py-2">
          Upload
          <input
            type="file"
            accept="image/png,image/jpeg,image/svg+xml"
            className="hidden"
            onChange={(e) => onFileSelected(e.target.files?.[0])}
          />
        </label>
      </div>
    </div>
  );
}

export default function SettingsClient({ initialSettings }) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [files, setFiles] = useState({ logo: null, signature: null, stamp: null });
  const [previews, setPreviews] = useState({
    logo: initialSettings.logoUrl,
    signature: initialSettings.signatureImageUrl,
    stamp: initialSettings.stampImageUrl,
  });

  const { register, handleSubmit } = useForm({
    defaultValues: {
      companyName: initialSettings.companyName || "",
      address: initialSettings.address || "",
      phone: initialSettings.phone || "",
      email: initialSettings.email || "",
      panNumber: initialSettings.panNumber || "",
      engineerLicenseNo: initialSettings.engineerLicenseNo || "",
    },
  });

  function pickFile(key, file) {
    if (!file) return;
    setFiles((f) => ({ ...f, [key]: file }));
    setPreviews((p) => ({ ...p, [key]: URL.createObjectURL(file) }));
  }

  async function onSubmit(data) {
    setSaving(true);
    setSaved(false);
    const formData = new FormData();
    Object.entries(data).forEach(([k, v]) => formData.append(k, v || ""));
    if (files.logo) formData.append("logo", files.logo);
    if (files.signature) formData.append("signature", files.signature);
    if (files.stamp) formData.append("stamp", files.stamp);

    const res = await fetch("/api/settings", { method: "PUT", body: formData });
    setSaving(false);
    if (res.ok) {
      setSaved(true);
      router.refresh();
      setTimeout(() => setSaved(false), 2500);
    }
  }

  return (
    <div className="max-w-2xl">
      <h1 className="font-display text-xl font-semibold mb-1">Company Settings</h1>
      <p className="text-sm text-foreground/55 mb-6">
        Used as the letterhead on every generated invoice, receipt, and report.
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="card-surface p-6 space-y-6">
        <section className="grid sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium mb-1.5">Company name</label>
            <input className={inputClass} {...register("companyName")} />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-sm font-medium mb-1.5">Address</label>
            <input className={inputClass} {...register("address")} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Phone</label>
            <input className={inputClass} {...register("phone")} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Email</label>
            <input className={inputClass} {...register("email")} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">PAN number</label>
            <input className={inputClass} {...register("panNumber")} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Engineer license no.</label>
            <input className={inputClass} {...register("engineerLicenseNo")} />
          </div>
        </section>

        <section className="grid sm:grid-cols-3 gap-4 pt-4 border-t border-border">
          <ImageSlot label="Logo" icon={ImageIcon} currentUrl={previews.logo} onFileSelected={(f) => pickFile("logo", f)} />
          <ImageSlot label="Signature" icon={PenTool} currentUrl={previews.signature} onFileSelected={(f) => pickFile("signature", f)} />
          <ImageSlot label="Stamp / Seal" icon={StampIcon} currentUrl={previews.stamp} onFileSelected={(f) => pickFile("stamp", f)} />
        </section>

        <div className="flex items-center gap-3 pt-2">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 rounded-lg bg-ink-900 text-white px-5 py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
            Save settings
          </button>
          {saved && <span className="text-xs text-status-approved font-medium">Saved</span>}
        </div>
      </form>
    </div>
  );
}
