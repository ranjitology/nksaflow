"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { formatDateTime } from "@/lib/utils";
import { History } from "lucide-react";

const ACTION_STYLE = {
  created: "text-status-approved",
  updated: "text-status-review",
  status_changed: "text-brass-700",
  deleted: "text-status-correction",
  uploaded: "text-ink-600",
};

export default function ActivityClient({ logs, modules }) {
  const [moduleFilter, setModuleFilter] = useState("");
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    return logs.filter((l) => {
      if (moduleFilter && l.module !== moduleFilter) return false;
      if (query) {
        const haystack = `${l.details || ""} ${l.user?.name || ""} ${l.project?.projectNumber || ""}`.toLowerCase();
        if (!haystack.includes(query.toLowerCase())) return false;
      }
      return true;
    });
  }, [logs, moduleFilter, query]);

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div>
        <h1 className="font-display text-xl font-semibold">Activity Log</h1>
        <p className="text-sm text-foreground/55 mt-0.5">
          Full audit trail of who did what, across every module. Showing the most recent 200 entries.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by detail, user, or project no..."
          className="flex-1 min-w-[220px] max-w-sm rounded-lg border border-border bg-surface px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30 focus:border-ink-500 transition"
        />
        <select
          value={moduleFilter}
          onChange={(e) => setModuleFilter(e.target.value)}
          className="rounded-lg border border-border bg-surface px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30"
        >
          <option value="">All modules</option>
          {modules.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
      </div>

      <div className="card-surface overflow-hidden">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-14 text-center">
            <History size={24} className="text-foreground/25" />
            <p className="text-sm text-foreground/45">No activity matches your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-foreground/45">
                  <th className="px-4 py-3 font-medium">When</th>
                  <th className="px-4 py-3 font-medium">User</th>
                  <th className="px-4 py-3 font-medium">Module</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                  <th className="px-4 py-3 font-medium">Detail</th>
                  <th className="px-4 py-3 font-medium">Project</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((l) => (
                  <tr key={l.id} className="hover:bg-surface-2/60 transition">
                    <td className="px-4 py-3 text-foreground/50 text-xs whitespace-nowrap">
                      {formatDateTime(l.createdAt)}
                    </td>
                    <td className="px-4 py-3">{l.user?.name || "System"}</td>
                    <td className="px-4 py-3 text-foreground/70">{l.module}</td>
                    <td className={`px-4 py-3 font-medium ${ACTION_STYLE[l.action] || ""}`}>{l.action}</td>
                    <td className="px-4 py-3 text-foreground/65 max-w-xs truncate">{l.details}</td>
                    <td className="px-4 py-3">
                      {l.project && (
                        <Link href={`/projects/${l.project.id}`} className="font-tabular text-ink-600 hover:underline">
                          {l.project.projectNumber}
                        </Link>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
