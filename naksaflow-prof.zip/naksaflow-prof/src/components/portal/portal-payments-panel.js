"use client";

import { useState } from "react";
import { formatCurrency, humanizeEnum } from "@/lib/utils";
import { generateInvoicePdf } from "@/lib/reports/pdf";
import { Loader2, FileDown, Receipt } from "lucide-react";

export default function PortalPaymentsPanel({ payments }) {
  const [generatingId, setGeneratingId] = useState(null);

  const totalPaid = payments.filter((pm) => pm.status === "PAID").reduce((s, pm) => s + pm.amount, 0);
  const totalDue = payments.filter((pm) => pm.status !== "PAID").reduce((s, pm) => s + pm.amount, 0);

  async function handleDocument(payment, isReceipt) {
    setGeneratingId(payment.id + (isReceipt ? "-r" : "-i"));
    try {
      const [invoiceRes, settingsRes] = await Promise.all([
        fetch(`/api/payments/${payment.id}/invoice`, { method: "POST" }),
        fetch("/api/settings"),
      ]);
      const invoiceData = await invoiceRes.json();
      const { settings } = await settingsRes.json();
      if (!invoiceRes.ok) throw new Error(invoiceData.error || "Failed");
      generateInvoicePdf({
        invoice: invoiceData.invoice,
        payment: invoiceData.payment,
        companySettings: settings,
        isReceipt,
      });
    } catch {
      alert("Could not generate the document. Please try again.");
    } finally {
      setGeneratingId(null);
    }
  }

  return (
    <div>
      <h4 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-2">Payment status</h4>
      <div className="flex justify-between text-sm">
        <span className="text-foreground/60">Paid</span>
        <span className="font-tabular text-status-approved font-medium">{formatCurrency(totalPaid)}</span>
      </div>
      <div className="flex justify-between text-sm mt-1 mb-3">
        <span className="text-foreground/60">Due</span>
        <span className="font-tabular text-status-correction font-medium">{formatCurrency(totalDue)}</span>
      </div>

      {payments.length > 0 && (
        <div className="space-y-1.5">
          {payments.map((pm) => (
            <div key={pm.id} className="flex items-center justify-between text-xs rounded-md px-2 py-1.5 -mx-2 hover:bg-surface-2/60 transition">
              <div className="min-w-0">
                <p className="font-medium truncate">{humanizeEnum(pm.type)}</p>
                <p className="text-foreground/45 font-tabular">{formatCurrency(pm.amount)} · {humanizeEnum(pm.status)}</p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleDocument(pm, false)}
                  disabled={generatingId === pm.id + "-i"}
                  title="Download invoice"
                  className="p-1.5 rounded-md text-foreground/45 hover:text-ink-700 hover:bg-surface-2 transition disabled:opacity-50"
                >
                  {generatingId === pm.id + "-i" ? <Loader2 size={13} className="animate-spin" /> : <FileDown size={13} />}
                </button>
                {pm.status === "PAID" && (
                  <button
                    onClick={() => handleDocument(pm, true)}
                    disabled={generatingId === pm.id + "-r"}
                    title="Download receipt"
                    className="p-1.5 rounded-md text-foreground/45 hover:text-status-approved hover:bg-surface-2 transition disabled:opacity-50"
                  >
                    {generatingId === pm.id + "-r" ? <Loader2 size={13} className="animate-spin" /> : <Receipt size={13} />}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
