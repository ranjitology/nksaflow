"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { PlusCircle, Loader2, FileDown, Receipt } from "lucide-react";
import Modal from "@/components/ui/modal";
import { formatCurrency, formatDate, humanizeEnum } from "@/lib/utils";
import { generateInvoicePdf } from "@/lib/reports/pdf";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

const STATUS_STYLE = {
  PAID: "text-status-approved",
  PENDING: "text-status-progress",
  PARTIAL: "text-status-review",
  OVERDUE: "text-status-correction",
};

export default function PaymentsClient({ initialPayments, projects }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState("");
  const [serverError, setServerError] = useState("");
  const [generatingId, setGeneratingId] = useState(null);
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm({
    defaultValues: { type: "CONSULTANCY_FEE", method: "CASH", status: "PENDING" },
  });

  const filtered = useMemo(
    () => (statusFilter ? initialPayments.filter((p) => p.status === statusFilter) : initialPayments),
    [initialPayments, statusFilter]
  );

  const totals = useMemo(() => {
    const paid = initialPayments.filter((p) => p.status === "PAID").reduce((s, p) => s + p.amount, 0);
    const outstanding = initialPayments.filter((p) => p.status !== "PAID").reduce((s, p) => s + p.amount, 0);
    return { paid, outstanding };
  }, [initialPayments]);

  async function onSubmit(data) {
    setServerError("");
    const res = await fetch("/api/payments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      setServerError("Could not record payment. Check the fields.");
      return;
    }
    reset();
    setOpen(false);
    router.refresh();
  }

  async function handleDocument(payment, isReceipt) {
    setGeneratingId(payment.id);
    try {
      const res = await fetch(`/api/payments/${payment.id}/invoice`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      generateInvoicePdf({ invoice: data.invoice, payment: data.payment, companySettings: data.companySettings, isReceipt });
      router.refresh();
    } catch {
      alert("Could not generate the document. Please try again.");
    } finally {
      setGeneratingId(null);
    }
  }

  return (
    <div className="space-y-5 max-w-[1300px]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-semibold">Payments</h1>
          <p className="text-sm text-foreground/55 mt-0.5">Consultancy fees, municipality fees, and settlement tracking.</p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-4 py-2 text-sm font-medium hover:bg-ink-800 transition"
        >
          <PlusCircle size={15} />
          Record payment
        </button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div className="card-surface p-4">
          <p className="text-xs text-foreground/55 mb-1">Total collected</p>
          <p className="font-display text-xl font-semibold font-tabular text-status-approved">{formatCurrency(totals.paid)}</p>
        </div>
        <div className="card-surface p-4">
          <p className="text-xs text-foreground/55 mb-1">Outstanding</p>
          <p className="font-display text-xl font-semibold font-tabular text-status-correction">{formatCurrency(totals.outstanding)}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {["", "PENDING", "PARTIAL", "PAID", "OVERDUE"].map((s) => (
          <button
            key={s || "all"}
            onClick={() => setStatusFilter(s)}
            className={`text-xs font-medium px-3 py-1.5 rounded-lg border transition ${
              statusFilter === s ? "bg-ink-900 text-white border-ink-900" : "border-border text-foreground/60 hover:text-foreground"
            }`}
          >
            {s ? humanizeEnum(s) : "All"}
          </button>
        ))}
      </div>

      <div className="card-surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-foreground/45">
                <th className="px-4 py-3 font-medium">Project</th>
                <th className="px-4 py-3 font-medium">Client</th>
                <th className="px-4 py-3 font-medium">Type</th>
                <th className="px-4 py-3 font-medium">Method</th>
                <th className="px-4 py-3 font-medium">Amount</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium text-right">Document</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-foreground/45">
                    No payments recorded yet.
                  </td>
                </tr>
              )}
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-surface-2/60 transition">
                  <td className="px-4 py-3 font-tabular text-ink-700">{p.project?.projectNumber}</td>
                  <td className="px-4 py-3">{p.client?.fullName}</td>
                  <td className="px-4 py-3 text-foreground/70">{humanizeEnum(p.type)}</td>
                  <td className="px-4 py-3 text-foreground/70">{humanizeEnum(p.method)}</td>
                  <td className="px-4 py-3 font-tabular font-medium">{formatCurrency(p.amount)}</td>
                  <td className={`px-4 py-3 font-medium ${STATUS_STYLE[p.status]}`}>{humanizeEnum(p.status)}</td>
                  <td className="px-4 py-3 text-foreground/50 text-xs">
                    {formatDate(p.paidAt || p.createdAt)}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleDocument(p, false)}
                        disabled={generatingId === p.id}
                        title="Generate invoice PDF"
                        className="p-1.5 rounded-md text-foreground/50 hover:text-ink-700 hover:bg-surface-2 transition disabled:opacity-50"
                      >
                        {generatingId === p.id ? <Loader2 size={14} className="animate-spin" /> : <FileDown size={14} />}
                      </button>
                      {p.status === "PAID" && (
                        <button
                          onClick={() => handleDocument(p, true)}
                          title="Generate receipt PDF"
                          className="p-1.5 rounded-md text-foreground/50 hover:text-status-approved hover:bg-surface-2 transition"
                        >
                          <Receipt size={14} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Record payment">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <select className={inputClass} {...register("projectId", { required: true })}>
            <option value="">Select project…</option>
            {projects.map((pr) => (
              <option key={pr.id} value={pr.id}>
                {pr.projectNumber} — {pr.client?.fullName}
              </option>
            ))}
          </select>
          <select className={inputClass} {...register("type")}>
            <option value="CONSULTANCY_FEE">Consultancy Fee</option>
            <option value="MUNICIPALITY_FEE">Municipality Fee</option>
            <option value="ADVANCE_PAYMENT">Advance Payment</option>
            <option value="DUE_PAYMENT">Due Payment</option>
          </select>
          <input type="number" step="0.01" className={inputClass} placeholder="Amount (Rs.)" {...register("amount", { required: true })} />
          <div className="grid grid-cols-2 gap-3">
            <select className={inputClass} {...register("method")}>
              <option value="CASH">Cash</option>
              <option value="BANK_TRANSFER">Bank Transfer</option>
              <option value="ESEWA">eSewa</option>
              <option value="KHALTI">Khalti</option>
            </select>
            <select className={inputClass} {...register("status")}>
              <option value="PENDING">Pending</option>
              <option value="PARTIAL">Partial</option>
              <option value="PAID">Paid</option>
              <option value="OVERDUE">Overdue</option>
            </select>
          </div>
          <input className={inputClass} placeholder="Note (optional)" {...register("note")} />
          {serverError && <p className="text-xs text-status-correction">{serverError}</p>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {isSubmitting && <Loader2 size={14} className="animate-spin" />}
            Save payment
          </button>
        </form>
      </Modal>
    </div>
  );
}
