"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  DndContext,
  useDraggable,
  useDroppable,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
} from "@dnd-kit/core";
import { STAGES } from "@/lib/stages";
import { formatCurrency } from "@/lib/utils";
import { GripVertical } from "lucide-react";

function ProjectCard({ project, dragging }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: project.id,
  });

  const style = transform
    ? { transform: `translate3d(${transform.x}px, ${transform.y}px, 0)` }
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`card-surface p-3 mb-2 cursor-grab active:cursor-grabbing ${
        isDragging ? "opacity-40" : ""
      } ${dragging ? "shadow-lg" : "hover:shadow-sm"} transition-shadow`}
      {...listeners}
      {...attributes}
    >
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <Link
          href={`/projects/${project.id}`}
          onClick={(e) => e.stopPropagation()}
          className="font-tabular text-xs font-semibold text-ink-700 hover:text-ink-900"
        >
          {project.projectNumber}
        </Link>
        <GripVertical size={13} className="text-foreground/25 shrink-0" />
      </div>
      <p className="text-[13px] font-medium truncate">{project.client?.fullName}</p>
      <p className="text-[11.5px] text-foreground/50 truncate">{project.municipality?.name}</p>
      <p className="text-[11.5px] font-tabular text-foreground/60 mt-1.5">
        {formatCurrency(project.estimatedCost)}
      </p>
    </div>
  );
}

function Column({ stage, projects }) {
  const { setNodeRef, isOver } = useDroppable({ id: stage.key });

  return (
    <div
      ref={setNodeRef}
      className={`w-[260px] shrink-0 rounded-xl p-2.5 transition-colors ${
        isOver ? "bg-ink-100/70 dark:bg-ink-900/40" : "bg-surface-2/60"
      }`}
    >
      <div className="flex items-center justify-between px-1.5 mb-2">
        <div className="flex items-center gap-1.5">
          <span
            className="w-2 h-2 rounded-full"
            style={{ background: `var(--${stage.color})` }}
          />
          <span className="text-[12.5px] font-semibold">{stage.label}</span>
        </div>
        <span className="text-[11px] font-tabular text-foreground/45">{projects.length}</span>
      </div>
      <div className="min-h-[60px]">
        {projects.map((p) => (
          <ProjectCard key={p.id} project={p} />
        ))}
      </div>
    </div>
  );
}

export default function ProjectKanban({ projects, onChange }) {
  const [activeId, setActiveId] = useState(null);
  const [localProjects, setLocalProjects] = useState(projects);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  // Keep local copy in sync whenever the parent refetches the project list.
  useEffect(() => {
    setLocalProjects(projects);
  }, [projects]);

  const byStage = STAGES.map((s) => ({
    stage: s,
    projects: localProjects.filter((p) => p.stage === s.key),
  }));

  const activeProject = localProjects.find((p) => p.id === activeId);

  async function handleDragEnd(event) {
    const { active, over } = event;
    setActiveId(null);
    if (!over) return;

    const newStage = over.id;
    const project = localProjects.find((p) => p.id === active.id);
    if (!project || project.stage === newStage) return;

    // Optimistic update
    setLocalProjects((prev) =>
      prev.map((p) => (p.id === project.id ? { ...p, stage: newStage } : p))
    );

    try {
      const res = await fetch(`/api/projects/${project.id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stage: newStage }),
      });
      if (!res.ok) throw new Error("failed");
    } catch {
      // revert on failure
      setLocalProjects((prev) =>
        prev.map((p) => (p.id === project.id ? { ...p, stage: project.stage } : p))
      );
    } finally {
      onChange?.();
    }
  }

  return (
    <DndContext
      sensors={sensors}
      onDragStart={(e) => setActiveId(e.active.id)}
      onDragEnd={handleDragEnd}
      onDragCancel={() => setActiveId(null)}
    >
      <div className="flex gap-3 overflow-x-auto pb-3">
        {byStage.map(({ stage, projects }) => (
          <Column key={stage.key} stage={stage} projects={projects} />
        ))}
      </div>
      <DragOverlay>
        {activeProject ? <ProjectCard project={activeProject} dragging /> : null}
      </DragOverlay>
    </DndContext>
  );
}
