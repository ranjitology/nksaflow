"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { UploadCloud, FileText, Loader2, Download } from "lucide-react";
import { formatDateTime, humanizeEnum } from "@/lib/utils";

const CATEGORIES = [
  ["ARCHITECTURAL_DRAWING", "Architectural Drawing"],
  ["STRUCTURAL_DRAWING", "Structural Drawing"],
  ["OWNERSHIP_CERTIFICATE", "Ownership Certificate"],
  ["CITIZENSHIP", "Citizenship"],
  ["TAX_CLEARANCE", "Tax Clearance"],
  ["MUNICIPALITY_DOCUMENT", "Municipality Document"],
  ["SURVEY_REPORT", "Survey Report"],
  ["SITE_PHOTO", "Site Photo"],
  ["OTHER", "Other"],
];

export default function DocumentManager({ projectId, documents }) {
  const router = useRouter();
  const [category, setCategory] = useState("OTHER");
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  async function handleFileChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError("");

    const formData = new FormData();
    formData.append("file", file);
    formData.append("category", category);

    try {
      const res = await fetch(`/api/projects/${projectId}/documents`, {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      router.refresh();
    } catch (err) {
      setError(err.message || "Upload failed");
    } finally {
      setUploading(false);
      e.target.value = "";
    }
  }

  return (
    <div className="card-surface p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold">Documents &amp; Drawings</h3>
        <div className="flex items-center gap-2">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded-lg border border-border bg-surface px-2.5 py-1.5 text-xs outline-none focus:ring-2 focus:ring-ink-500/30"
          >
            {CATEGORIES.map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
          <label className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-3 py-1.5 text-xs font-medium hover:bg-ink-800 transition cursor-pointer">
            {uploading ? <Loader2 size={13} className="animate-spin" /> : <UploadCloud size={13} />}
            Upload
            <input
              type="file"
              className="hidden"
              accept=".pdf,.dwg,.dxf,.jpg,.jpeg,.png"
              onChange={handleFileChange}
              disabled={uploading}
            />
          </label>
        </div>
      </div>

      {error && <p className="text-xs text-status-correction mb-3">{error}</p>}

      {documents.length === 0 ? (
        <p className="text-sm text-foreground/45 text-center py-8">
          No documents uploaded yet. Supported: PDF, DWG, DXF, JPG, PNG.
        </p>
      ) : (
        <div className="divide-y divide-border">
          {documents.map((d) => (
            <a
              key={d.id}
              href={d.fileUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between py-2.5 hover:bg-surface-2/50 -mx-2 px-2 rounded-lg transition"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText size={15} className="text-ink-600 shrink-0" />
                <div className="min-w-0">
                  <p className="text-[13px] font-medium truncate">{d.fileName}</p>
                  <p className="text-[11px] text-foreground/45">
                    {humanizeEnum(d.category)} · v{d.version} · {formatDateTime(d.createdAt)}
                  </p>
                </div>
              </div>
              <Download size={14} className="text-foreground/35 shrink-0 ml-2" />
            </a>
          ))}
        </div>
      )}
    </div>
  );
}
