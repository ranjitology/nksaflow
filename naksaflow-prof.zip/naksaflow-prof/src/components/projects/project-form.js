"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { projectSchema } from "@/lib/validations/project";
import { Loader2 } from "lucide-react";
import Link from "next/link";

const BUILDING_TYPES = [
  ["RESIDENTIAL", "Residential"],
  ["COMMERCIAL", "Commercial"],
  ["INDUSTRIAL", "Industrial"],
  ["INSTITUTIONAL", "Institutional"],
  ["MIXED_USE", "Mixed Use"],
  ["OTHER", "Other"],
];

const LAND_UNITS = ["Ropani", "Aana", "Sq. ft", "Sq. m"];

function Field({ label, error, children, required }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">
        {label} {required && <span className="text-status-correction">*</span>}
      </label>
      {children}
      {error && <p className="text-xs text-status-correction mt-1">{error.message}</p>}
    </div>
  );
}

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

export default function ProjectForm() {
  const router = useRouter();
  const [clients, setClients] = useState([]);
  const [municipalities, setMunicipalities] = useState([]);
  const [engineers, setEngineers] = useState([]);
  const [serverError, setServerError] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(projectSchema),
    defaultValues: { landAreaUnit: "Ropani", buildingType: "RESIDENTIAL", numberOfFloors: 1 },
  });

  useEffect(() => {
    fetch("/api/clients").then((r) => r.json()).then((d) => setClients(d.clients || []));
    fetch("/api/municipalities").then((r) => r.json()).then((d) => setMunicipalities(d.municipalities || []));
    fetch("/api/users").then((r) => r.json()).then((d) => setEngineers(d.users || []));
  }, []);

  const onSubmit = async (data) => {
    setServerError("");
    const res = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      setServerError("Could not create project. Please check the form and try again.");
      return;
    }
    const { project } = await res.json();
    router.push(`/projects/${project.id}`);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="card-surface p-6 space-y-6">
      <section>
        <h3 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-3">
          Client &amp; Municipality
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Client" error={errors.clientId} required>
            <select className={inputClass} {...register("clientId")}>
              <option value="">Select client…</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} — {c.phone}
                </option>
              ))}
            </select>
            {clients.length === 0 && (
              <p className="text-xs text-foreground/45 mt-1">
                No clients yet.{" "}
                <Link href="/clients" className="text-ink-600 underline">
                  Add one first
                </Link>
                .
              </p>
            )}
          </Field>
          <Field label="Municipality" error={errors.municipalityId} required>
            <select className={inputClass} {...register("municipalityId")}>
              <option value="">Select municipality…</option>
              {municipalities.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
      </section>

      <section>
        <h3 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-3">
          Land &amp; Building
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Ward Number" error={errors.wardNumber} required>
            <input className={inputClass} placeholder="e.g. 4" {...register("wardNumber")} />
          </Field>
          <Field label="Kitta Number" error={errors.kittaNumber} required>
            <input className={inputClass} placeholder="e.g. 245/b" {...register("kittaNumber")} />
          </Field>
          <Field label="Land Area" error={errors.landArea} required>
            <input type="number" step="0.01" className={inputClass} placeholder="e.g. 4.5" {...register("landArea")} />
          </Field>
          <Field label="Land Area Unit">
            <select className={inputClass} {...register("landAreaUnit")}>
              {LAND_UNITS.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Building Type" required>
            <select className={inputClass} {...register("buildingType")}>
              {BUILDING_TYPES.map(([v, l]) => (
                <option key={v} value={v}>
                  {l}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Number of Floors" error={errors.numberOfFloors} required>
            <input type="number" min="1" className={inputClass} {...register("numberOfFloors")} />
          </Field>
          <Field label="Estimated Cost (Rs.)" error={errors.estimatedCost}>
            <input type="number" step="0.01" className={inputClass} placeholder="e.g. 3500000" {...register("estimatedCost")} />
          </Field>
          <Field label="Project Start Date">
            <input type="date" className={inputClass} {...register("startDate")} />
          </Field>
        </div>
      </section>

      <section>
        <h3 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-3">
          Team
        </h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <Field label="Engineer">
            <select className={inputClass} {...register("engineerId")}>
              <option value="">Unassigned</option>
              {engineers.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Architect">
            <select className={inputClass} {...register("architectId")}>
              <option value="">Unassigned</option>
              {engineers.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Surveyor">
            <select className={inputClass} {...register("surveyorId")}>
              <option value="">Unassigned</option>
              {engineers.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
      </section>

      {serverError && (
        <div className="rounded-lg bg-status-correction/10 border border-status-correction/30 px-3 py-2 text-sm text-status-correction">
          {serverError}
        </div>
      )}

      <div className="flex items-center gap-3 pt-2">
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex items-center gap-2 rounded-lg bg-ink-900 text-white px-5 py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
        >
          {isSubmitting && <Loader2 size={15} className="animate-spin" />}
          Create project
        </button>
        <button
          type="button"
          onClick={() => router.back()}
          className="px-5 py-2.5 text-sm font-medium text-foreground/60 hover:text-foreground transition"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
