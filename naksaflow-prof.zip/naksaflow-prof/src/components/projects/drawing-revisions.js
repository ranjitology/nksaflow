"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Loader2, FileText, GitCompare, X } from "lucide-react";
import Modal from "@/components/ui/modal";
import { formatDate } from "@/lib/utils";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

export default function DrawingRevisions({ projectId, revisions }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [compareSelection, setCompareSelection] = useState([]);
  const [compareOpen, setCompareOpen] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const formEl = e.target;
    const formData = new FormData(formEl);

    try {
      const res = await fetch(`/api/projects/${projectId}/revisions`, { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      setOpen(false);
      formEl.reset();
      router.refresh();
    } catch (err) {
      setError(err.message || "Could not save the revision.");
    } finally {
      setSubmitting(false);
    }
  }

  function toggleCompare(id) {
    setCompareSelection((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      if (prev.length >= 2) return [prev[1], id];
      return [...prev, id];
    });
  }

  const compareRevisions = revisions.filter((r) => compareSelection.includes(r.id));

  return (
    <div className="card-surface p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold">Drawing Revisions</h3>
        <div className="flex items-center gap-2">
          {compareSelection.length === 2 && (
            <button
              onClick={() => setCompareOpen(true)}
              className="flex items-center gap-1.5 text-xs font-medium text-ink-600 hover:text-ink-800"
            >
              <GitCompare size={13} />
              Compare
            </button>
          )}
          <button
            onClick={() => setOpen(true)}
            className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-3 py-1.5 text-xs font-medium hover:bg-ink-800 transition"
          >
            <Plus size={13} />
            New revision
          </button>
        </div>
      </div>

      {revisions.length === 0 ? (
        <p className="text-sm text-foreground/45 text-center py-8">No revisions logged yet.</p>
      ) : (
        <div className="space-y-0">
          {revisions.map((r, i) => (
            <div key={r.id} className="flex gap-3">
              <div className="flex flex-col items-center">
                <label className="cursor-pointer">
                  <input
                    type="checkbox"
                    checked={compareSelection.includes(r.id)}
                    onChange={() => toggleCompare(r.id)}
                    className="sr-only peer"
                  />
                  <span className="w-6 h-6 rounded-full bg-brass-100 text-brass-700 flex items-center justify-center text-[10px] font-tabular font-semibold peer-checked:bg-ink-900 peer-checked:text-white transition">
                    R{r.revisionNumber}
                  </span>
                </label>
                {i !== revisions.length - 1 && <div className="w-0.5 flex-1 min-h-[20px] bg-border" />}
              </div>
              <div className="pb-5 min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[13px] font-medium">{r.revisionReason}</p>
                  <span className="text-[11px] text-foreground/45 shrink-0">{formatDate(r.revisionDate)}</span>
                </div>
                <p className="text-[11.5px] text-foreground/50">{r.engineer?.name}</p>
                {r.engineerNotes && <p className="text-[12px] text-foreground/65 mt-1">{r.engineerNotes}</p>}
                {r.fileUrl && (
                  <a
                    href={r.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11.5px] text-ink-600 hover:underline mt-1.5"
                  >
                    <FileText size={11} />
                    View file
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="New drawing revision">
        <form onSubmit={onSubmit} className="space-y-3">
          <input type="date" name="revisionDate" required className={inputClass} defaultValue={new Date().toISOString().slice(0, 10)} />
          <input name="revisionReason" required placeholder="Revision reason (e.g. setback correction)" className={inputClass} />
          <textarea name="engineerNotes" rows={3} placeholder="Engineer notes" className={inputClass} />
          <div>
            <label className="text-xs text-foreground/55 mb-1 block">Revised drawing file (optional)</label>
            <input type="file" name="file" accept=".pdf,.dwg,.dxf,.jpg,.jpeg,.png" className="text-xs" />
          </div>
          {error && <p className="text-xs text-status-correction">{error}</p>}
          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {submitting && <Loader2 size={14} className="animate-spin" />}
            Save revision
          </button>
        </form>
      </Modal>

      <Modal open={compareOpen} onClose={() => setCompareOpen(false)} title="Compare revisions" width="max-w-2xl">
        <div className="grid grid-cols-2 gap-4">
          {compareRevisions.map((r) => (
            <div key={r.id} className="rounded-lg border border-border p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-tabular font-semibold text-ink-700">Revision {r.revisionNumber}</span>
                <span className="text-[11px] text-foreground/45">{formatDate(r.revisionDate)}</span>
              </div>
              <p className="text-[13px] font-medium mb-1.5">{r.revisionReason}</p>
              <p className="text-[12px] text-foreground/65">{r.engineerNotes || "No additional notes."}</p>
              <p className="text-[11px] text-foreground/45 mt-2">{r.engineer?.name}</p>
              {r.fileUrl && (
                <a href={r.fileUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-[11.5px] text-ink-600 hover:underline mt-2">
                  <FileText size={11} />
                  View file
                </a>
              )}
            </div>
          ))}
        </div>
        <button
          onClick={() => setCompareOpen(false)}
          className="mt-4 flex items-center gap-1.5 text-xs text-foreground/55 hover:text-foreground mx-auto"
        >
          <X size={12} />
          Close
        </button>
      </Modal>
    </div>
  );
}
