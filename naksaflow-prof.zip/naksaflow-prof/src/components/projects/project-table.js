"use client";

import { useState } from "react";
import Link from "next/link";
import { formatDate, formatCurrency, humanizeEnum } from "@/lib/utils";
import StageBadge from "./stage-badge";
import { FileSearch, Loader2, FileSpreadsheet } from "lucide-react";
import { STAGES } from "@/lib/stages";
import { downloadRowsAsExcel } from "@/lib/reports/excel";

export default function ProjectTable({ projects, onChange }) {
  const [selected, setSelected] = useState(new Set());
  const [bulkStage, setBulkStage] = useState("");
  const [applying, setApplying] = useState(false);

  if (!projects.length) {
    return (
      <div className="card-surface p-12 flex flex-col items-center text-center gap-2">
        <FileSearch size={28} className="text-foreground/30" />
        <p className="text-sm font-medium">No projects found</p>
        <p className="text-xs text-foreground/50">Try a different search, or create a new project.</p>
      </div>
    );
  }

  const allSelected = selected.size > 0 && selected.size === projects.length;

  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(projects.map((p) => p.id)));
  }

  function toggleOne(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  async function applyBulkStage() {
    if (!bulkStage || selected.size === 0) return;
    setApplying(true);
    try {
      await Promise.all(
        [...selected].map((id) =>
          fetch(`/api/projects/${id}/status`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ stage: bulkStage, note: "Bulk update" }),
          })
        )
      );
      setSelected(new Set());
      setBulkStage("");
      onChange?.();
    } finally {
      setApplying(false);
    }
  }

  function exportSelected() {
    const rows = projects
      .filter((p) => selected.size === 0 || selected.has(p.id))
      .map((p) => ({
        "Project No.": p.projectNumber,
        "Client": p.client?.fullName,
        "Municipality": p.municipality?.name,
        "Ward": p.wardNumber,
        "Kitta No.": p.kittaNumber,
        "Building Type": humanizeEnum(p.buildingType),
        "Estimated Cost": p.estimatedCost,
        "Stage": humanizeEnum(p.stage),
        "Updated": formatDate(p.updatedAt),
      }));
    downloadRowsAsExcel(rows, "Projects-Export.xlsx", "Projects");
  }

  return (
    <div className="space-y-3">
      {selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-2.5 rounded-lg border border-ink-500/30 bg-ink-100/50 px-3.5 py-2.5">
          <span className="text-xs font-medium text-ink-800">{selected.size} selected</span>
          <select
            value={bulkStage}
            onChange={(e) => setBulkStage(e.target.value)}
            className="rounded-md border border-border bg-surface px-2 py-1.5 text-xs outline-none focus:ring-2 focus:ring-ink-500/30"
          >
            <option value="">Move to stage…</option>
            {STAGES.map((s) => (
              <option key={s.key} value={s.key}>
                {s.label}
              </option>
            ))}
          </select>
          <button
            onClick={applyBulkStage}
            disabled={!bulkStage || applying}
            className="flex items-center gap-1.5 rounded-md bg-ink-900 text-white px-3 py-1.5 text-xs font-medium hover:bg-ink-800 transition disabled:opacity-50"
          >
            {applying && <Loader2 size={12} className="animate-spin" />}
            Apply
          </button>
          <button
            onClick={exportSelected}
            className="flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs font-medium text-foreground/65 hover:text-foreground transition ml-auto"
          >
            <FileSpreadsheet size={12} />
            Export selected
          </button>
        </div>
      )}

      <div className="card-surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-foreground/45">
                <th className="px-4 py-3 font-medium w-8">
                  <input type="checkbox" checked={allSelected} onChange={toggleAll} className="accent-ink-900" />
                </th>
                <th className="px-4 py-3 font-medium">Project No.</th>
                <th className="px-4 py-3 font-medium">Client</th>
                <th className="px-4 py-3 font-medium">Municipality</th>
                <th className="px-4 py-3 font-medium">Ward / Kitta</th>
                <th className="px-4 py-3 font-medium">Building Type</th>
                <th className="px-4 py-3 font-medium">Est. Cost</th>
                <th className="px-4 py-3 font-medium">Stage</th>
                <th className="px-4 py-3 font-medium">Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {projects.map((p) => (
                <tr key={p.id} className={`hover:bg-surface-2/60 transition ${selected.has(p.id) ? "bg-ink-100/40" : ""}`}>
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={selected.has(p.id)}
                      onChange={() => toggleOne(p.id)}
                      className="accent-ink-900"
                    />
                  </td>
                  <td className="px-4 py-3">
                    <Link href={`/projects/${p.id}`} className="font-tabular font-medium text-ink-700 hover:text-ink-900">
                      {p.projectNumber}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{p.client?.fullName}</td>
                  <td className="px-4 py-3">{p.municipality?.name}</td>
                  <td className="px-4 py-3 font-tabular text-foreground/70">
                    W-{p.wardNumber} / {p.kittaNumber}
                  </td>
                  <td className="px-4 py-3 text-foreground/70">{humanizeEnum(p.buildingType)}</td>
                  <td className="px-4 py-3 font-tabular">{formatCurrency(p.estimatedCost)}</td>
                  <td className="px-4 py-3">
                    <StageBadge stage={p.stage} size="sm" />
                  </td>
                  <td className="px-4 py-3 text-foreground/50 text-xs">{formatDate(p.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
