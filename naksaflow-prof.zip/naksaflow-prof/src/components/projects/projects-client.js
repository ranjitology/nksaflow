"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { LayoutGrid, Table2, PlusCircle, Search } from "lucide-react";
import ProjectTable from "./project-table";
import ProjectKanban from "./project-kanban";

export default function ProjectsClient({ initialQuery }) {
  const [view, setView] = useState("table");
  const [query, setQuery] = useState(initialQuery || "");
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (q) => {
    setLoading(true);
    const res = await fetch(`/api/projects${q ? `?q=${encodeURIComponent(q)}` : ""}`);
    const data = await res.json();
    setProjects(data.projects || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load(query);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleSearch(e) {
    e.preventDefault();
    load(query);
  }

  return (
    <div className="space-y-5 max-w-[1400px]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-semibold">Projects</h1>
          <p className="text-sm text-foreground/55 mt-0.5">
            Every Naksa Pass file, from inquiry through stamped approval.
          </p>
        </div>
        <Link
          href="/projects/new"
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-4 py-2 text-sm font-medium hover:bg-ink-800 transition"
        >
          <PlusCircle size={15} />
          New project
        </Link>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <form onSubmit={handleSearch} className="relative flex-1 min-w-[240px] max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search project no., client, kitta..."
            className="w-full rounded-lg border border-border bg-surface pl-8 pr-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30 focus:border-ink-500 transition"
          />
        </form>

        <div className="flex items-center rounded-lg border border-border p-0.5 bg-surface ml-auto">
          <button
            onClick={() => setView("table")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
              view === "table" ? "bg-ink-900 text-white" : "text-foreground/60 hover:text-foreground"
            }`}
          >
            <Table2 size={14} />
            Table
          </button>
          <button
            onClick={() => setView("kanban")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
              view === "kanban" ? "bg-ink-900 text-white" : "text-foreground/60 hover:text-foreground"
            }`}
          >
            <LayoutGrid size={14} />
            Kanban
          </button>
        </div>
      </div>

      {loading ? (
        <div className="card-surface p-10 text-center text-sm text-foreground/50">Loading projects…</div>
      ) : view === "table" ? (
        <ProjectTable projects={projects} onChange={() => load(query)} />
      ) : (
        <ProjectKanban projects={projects} onChange={() => load(query)} />
      )}
    </div>
  );
}
