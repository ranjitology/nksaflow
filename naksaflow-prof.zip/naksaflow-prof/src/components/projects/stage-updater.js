"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { STAGES } from "@/lib/stages";
import { Loader2, ArrowRightCircle } from "lucide-react";

export default function StageUpdater({ projectId, currentStage }) {
  const router = useRouter();
  const [stage, setStage] = useState(currentStage);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function handleUpdate() {
    if (stage === currentStage) return;
    setSubmitting(true);
    setError("");
    try {
      const res = await fetch(`/api/projects/${projectId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stage, note: note || undefined }),
      });
      if (!res.ok) throw new Error("failed");
      setNote("");
      router.refresh();
    } catch {
      setError("Could not update the stage. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="card-surface p-4">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-3">
        Update stage
      </h3>
      <div className="space-y-2.5">
        <select
          value={stage}
          onChange={(e) => setStage(e.target.value)}
          className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30 focus:border-ink-500 transition"
        >
          {STAGES.map((s) => (
            <option key={s.key} value={s.key}>
              {s.label}
            </option>
          ))}
        </select>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Optional note (e.g. correction reason)"
          className="w-full rounded-lg border border-border bg-surface px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30 focus:border-ink-500 transition"
        />
        {error && <p className="text-xs text-status-correction">{error}</p>}
        <button
          onClick={handleUpdate}
          disabled={submitting || stage === currentStage}
          className="w-full flex items-center justify-center gap-1.5 rounded-lg bg-ink-900 text-white py-2 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-50"
        >
          {submitting ? <Loader2 size={14} className="animate-spin" /> : <ArrowRightCircle size={14} />}
          Save stage
        </button>
      </div>
    </div>
  );
}
