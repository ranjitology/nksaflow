"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MapPin, Camera, Plus, Loader2, FileDown, LocateFixed } from "lucide-react";
import Modal from "@/components/ui/modal";
import { formatDate } from "@/lib/utils";
import { generateSurveyReportPdf } from "@/lib/reports/pdf";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

export default function SiteSurveyManager({ project, surveys }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [coords, setCoords] = useState({ lat: "", lng: "" });
  const [locating, setLocating] = useState(false);
  const [generatingId, setGeneratingId] = useState(null);

  function useMyLocation() {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude.toFixed(6), lng: pos.coords.longitude.toFixed(6) });
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }

  async function onSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const formEl = e.target;
    const formData = new FormData(formEl);
    if (coords.lat) formData.set("gpsLatitude", coords.lat);
    if (coords.lng) formData.set("gpsLongitude", coords.lng);

    try {
      const res = await fetch(`/api/projects/${project.id}/surveys`, { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      setOpen(false);
      setCoords({ lat: "", lng: "" });
      formEl.reset();
      router.refresh();
    } catch (err) {
      setError(err.message || "Could not save the survey.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleReport(survey) {
    setGeneratingId(survey.id);
    try {
      const settingsRes = await fetch("/api/settings");
      const { settings } = await settingsRes.json();
      generateSurveyReportPdf({ project, survey, companySettings: settings });
    } finally {
      setGeneratingId(null);
    }
  }

  return (
    <div className="card-surface p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold">Site Survey</h3>
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-3 py-1.5 text-xs font-medium hover:bg-ink-800 transition"
        >
          <Plus size={13} />
          Log survey
        </button>
      </div>

      {surveys.length === 0 ? (
        <p className="text-sm text-foreground/45 text-center py-8">No site surveys logged yet.</p>
      ) : (
        <div className="space-y-3">
          {surveys.map((s) => (
            <div key={s.id} className="rounded-lg border border-border p-3.5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[13px] font-medium">{formatDate(s.surveyDate)}</p>
                  <p className="text-[11.5px] text-foreground/50">{s.engineer?.name || "Unassigned"}</p>
                </div>
                <button
                  onClick={() => handleReport(s)}
                  disabled={generatingId === s.id}
                  className="flex items-center gap-1 text-[11px] font-medium text-ink-600 hover:text-ink-800 shrink-0"
                >
                  {generatingId === s.id ? <Loader2 size={12} className="animate-spin" /> : <FileDown size={12} />}
                  Report
                </button>
              </div>

              {s.gpsLatitude && s.gpsLongitude && (
                <a
                  href={`https://www.google.com/maps?q=${s.gpsLatitude},${s.gpsLongitude}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-[11.5px] text-ink-600 hover:underline mt-1.5"
                >
                  <MapPin size={11} />
                  {s.gpsLatitude.toFixed(5)}, {s.gpsLongitude.toFixed(5)}
                </a>
              )}

              {s.siteNotes && <p className="text-[12px] text-foreground/65 mt-2">{s.siteNotes}</p>}

              {s.photos?.length > 0 && (
                <p className="flex items-center gap-1 text-[11px] text-foreground/45 mt-2">
                  <Camera size={11} />
                  {s.photos.length} photo{s.photos.length > 1 ? "s" : ""}
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Log site survey">
        <form onSubmit={onSubmit} className="space-y-3">
          <input type="date" name="surveyDate" required className={inputClass} defaultValue={new Date().toISOString().slice(0, 10)} />

          <div className="flex items-center gap-2">
            <input
              value={coords.lat}
              onChange={(e) => setCoords((c) => ({ ...c, lat: e.target.value }))}
              placeholder="Latitude"
              className={inputClass}
            />
            <input
              value={coords.lng}
              onChange={(e) => setCoords((c) => ({ ...c, lng: e.target.value }))}
              placeholder="Longitude"
              className={inputClass}
            />
            <button
              type="button"
              onClick={useMyLocation}
              disabled={locating}
              title="Use my current location"
              className="shrink-0 p-2.5 rounded-lg border border-border text-foreground/55 hover:text-ink-700 hover:bg-surface-2 transition"
            >
              {locating ? <Loader2 size={15} className="animate-spin" /> : <LocateFixed size={15} />}
            </button>
          </div>

          <textarea name="siteNotes" rows={3} placeholder="Site notes" className={inputClass} />

          <div>
            <label className="text-xs text-foreground/55 mb-1 block">Site photos (optional)</label>
            <input type="file" name="photos" multiple accept="image/jpeg,image/png" className="text-xs" />
          </div>

          {error && <p className="text-xs text-status-correction">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {submitting && <Loader2 size={14} className="animate-spin" />}
            Save survey
          </button>
        </form>
      </Modal>
    </div>
  );
}
