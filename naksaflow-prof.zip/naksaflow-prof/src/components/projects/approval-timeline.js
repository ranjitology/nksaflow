import { STAGES, STAGE_INDEX } from "@/lib/stages";
import { formatDateTime } from "@/lib/utils";
import { Check } from "lucide-react";

export default function ApprovalTimeline({ currentStage, statusHistory = [] }) {
  const currentIndex = STAGE_INDEX[currentStage] ?? 0;

  const lastEventForStage = (stageKey) =>
    [...statusHistory].reverse().find((h) => h.stage === stageKey);

  return (
    <div className="space-y-0">
      {STAGES.map((stage, i) => {
        const done = i < currentIndex;
        const isCurrent = i === currentIndex;
        const event = lastEventForStage(stage.key);
        const isLast = i === STAGES.length - 1;

        return (
          <div key={stage.key} className="flex gap-3">
            <div className="flex flex-col items-center">
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border-2 ${
                  done || isCurrent
                    ? "border-transparent text-white"
                    : "border-border text-foreground/30 bg-surface"
                }`}
                style={
                  done || isCurrent
                    ? { background: `var(--${stage.color})` }
                    : undefined
                }
              >
                {done ? <Check size={13} /> : <span className="text-[10px] font-tabular">{i + 1}</span>}
              </div>
              {!isLast && (
                <div
                  className={`w-0.5 flex-1 min-h-[22px] ${done ? "" : "bg-border"}`}
                  style={done ? { background: `var(--${stage.color})` } : undefined}
                />
              )}
            </div>
            <div className={`pb-5 ${isCurrent ? "" : "opacity-80"}`}>
              <p
                className={`text-[13px] leading-6 ${
                  isCurrent ? "font-semibold" : done ? "font-medium" : "text-foreground/45"
                }`}
              >
                {stage.label}
                {isCurrent && (
                  <span className="ml-2 text-[10px] uppercase tracking-wide text-brass-600 font-tabular">
                    current
                  </span>
                )}
              </p>
              {event && (
                <p className="text-[11.5px] text-foreground/45 -mt-0.5">
                  {formatDateTime(event.changedAt)}
                  {event.note ? ` · ${event.note}` : ""}
                </p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
