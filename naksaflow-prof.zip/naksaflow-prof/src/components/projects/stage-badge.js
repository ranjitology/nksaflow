import { stageLabel, stageColorVar } from "@/lib/stages";
import { cn } from "@/lib/utils";

export default function StageBadge({ stage, size = "md" }) {
  const label = stageLabel(stage);
  const colorVar = stageColorVar(stage);

  if (stage === "APPROVED" || stage === "COMPLETED") {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1 rounded-full border font-medium font-tabular uppercase tracking-wide",
          size === "sm" ? "text-[10px] px-2 py-0.5" : "text-[11px] px-2.5 py-1"
        )}
        style={{
          color: `var(--${colorVar})`,
          borderColor: `var(--${colorVar})`,
          background: `color-mix(in srgb, var(--${colorVar}) 10%, transparent)`,
        }}
      >
        <svg width="9" height="9" viewBox="0 0 10 10" fill="none">
          <circle cx="5" cy="5" r="4.2" stroke="currentColor" strokeWidth="1" />
          <path d="M2.8 5.1l1.4 1.4L7.2 3" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        {label}
      </span>
    );
  }

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md font-medium",
        size === "sm" ? "text-[10px] px-2 py-0.5" : "text-[11px] px-2.5 py-1"
      )}
      style={{
        color: `var(--${colorVar})`,
        background: `color-mix(in srgb, var(--${colorVar}) 14%, transparent)`,
      }}
    >
      {label}
    </span>
  );
}
