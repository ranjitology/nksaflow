"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { PlusCircle, Loader2, Building2 } from "lucide-react";
import Modal from "@/components/ui/modal";
import { formatCurrency } from "@/lib/utils";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

export default function MunicipalitiesClient({ initialMunicipalities }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [serverError, setServerError] = useState("");
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm();

  async function onSubmit(data) {
    setServerError("");
    const res = await fetch("/api/municipalities", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      setServerError("Could not save municipality.");
      return;
    }
    reset();
    setOpen(false);
    router.refresh();
  }

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-semibold">Municipalities</h1>
          <p className="text-sm text-foreground/55 mt-0.5">
            Approval authorities you file Naksa Pass submissions with.
          </p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-4 py-2 text-sm font-medium hover:bg-ink-800 transition"
        >
          <PlusCircle size={15} />
          Add municipality
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {initialMunicipalities.length === 0 && (
          <p className="text-sm text-foreground/45 col-span-full text-center py-10">
            No municipalities added yet.
          </p>
        )}
        {initialMunicipalities.map((m) => (
          <div key={m.id} className="card-surface p-4">
            <div className="flex items-center gap-2.5 mb-2">
              <div className="w-8 h-8 rounded-lg bg-ink-100 text-ink-700 flex items-center justify-center">
                <Building2 size={15} />
              </div>
              <h3 className="font-medium text-sm">{m.name}</h3>
            </div>
            <div className="text-xs text-foreground/55 space-y-1">
              <p>{m.contactPerson || "No contact person set"}</p>
              <p className="font-tabular">{m.contactPhone || "—"}</p>
              <div className="flex items-center justify-between pt-2 mt-2 border-t border-border">
                <span>{m._count.projects} projects</span>
                <span className="font-tabular">{formatCurrency(m.standardFee)} fee</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Add municipality">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <input className={inputClass} placeholder="Municipality name" {...register("name", { required: true })} />
          <input className={inputClass} placeholder="Contact person" {...register("contactPerson")} />
          <div className="grid grid-cols-2 gap-3">
            <input className={inputClass} placeholder="Contact phone" {...register("contactPhone")} />
            <input className={inputClass} placeholder="Contact email" {...register("contactEmail")} />
          </div>
          <input type="number" step="0.01" className={inputClass} placeholder="Standard fee (Rs.)" {...register("standardFee")} />
          <textarea className={inputClass} rows={3} placeholder="Approval requirements" {...register("approvalRequirements")} />
          {serverError && <p className="text-xs text-status-correction">{serverError}</p>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {isSubmitting && <Loader2 size={14} className="animate-spin" />}
            Save municipality
          </button>
        </form>
      </Modal>
    </div>
  );
}
