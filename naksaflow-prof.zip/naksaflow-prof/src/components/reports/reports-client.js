"use client";

import { useState } from "react";
import {
  FileBarChart2,
  Building2,
  Users,
  CalendarCheck,
  Banknote,
  AlertTriangle,
  Loader2,
  FileSpreadsheet,
  FileText,
} from "lucide-react";
import { downloadRowsAsExcel } from "@/lib/reports/excel";
import { generateProjectReportPdf } from "@/lib/reports/pdf";

function ReportCard({ icon: Icon, title, description, children }) {
  return (
    <div className="card-surface p-5 flex flex-col gap-3">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-lg bg-ink-100 text-ink-700 flex items-center justify-center shrink-0">
          <Icon size={16} />
        </div>
        <div>
          <h3 className="text-sm font-semibold">{title}</h3>
          <p className="text-xs text-foreground/50">{description}</p>
        </div>
      </div>
      <div className="mt-1">{children}</div>
    </div>
  );
}

function ExcelButton({ endpoint, filename, sheetName, loadingKey, loading, setLoading }) {
  async function handleClick() {
    setLoading(loadingKey);
    try {
      const res = await fetch(endpoint);
      const data = await res.json();
      downloadRowsAsExcel(data.rows, filename, sheetName);
    } finally {
      setLoading(null);
    }
  }
  return (
    <button
      onClick={handleClick}
      disabled={loading === loadingKey}
      className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-3.5 py-2 text-xs font-medium hover:bg-ink-800 transition disabled:opacity-60"
    >
      {loading === loadingKey ? <Loader2 size={13} className="animate-spin" /> : <FileSpreadsheet size={13} />}
      Export Excel
    </button>
  );
}

export default function ReportsClient({ projects }) {
  const [loading, setLoading] = useState(null);
  const [selectedProject, setSelectedProject] = useState(projects[0]?.id || "");

  async function handleProjectReport() {
    if (!selectedProject) return;
    setLoading("project");
    try {
      const [projectRes, settingsRes] = await Promise.all([
        fetch(`/api/projects/${selectedProject}`),
        fetch("/api/settings"),
      ]);
      const { project } = await projectRes.json();
      const { settings } = await settingsRes.json();
      generateProjectReportPdf({ project, companySettings: settings });
    } finally {
      setLoading(null);
    }
  }

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div>
        <h1 className="font-display text-xl font-semibold">Reports</h1>
        <p className="text-sm text-foreground/55 mt-0.5">
          Generate PDF and Excel reports across projects, municipalities, engineers, and revenue.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <ReportCard
          icon={FileBarChart2}
          title="Project Report"
          description="Full detail + approval timeline for one project, as a stamped PDF."
        >
          <div className="flex items-center gap-2">
            <select
              value={selectedProject}
              onChange={(e) => setSelectedProject(e.target.value)}
              className="flex-1 rounded-lg border border-border bg-surface px-2.5 py-2 text-xs outline-none focus:ring-2 focus:ring-ink-500/30"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.projectNumber} — {p.client?.fullName}
                </option>
              ))}
            </select>
            <button
              onClick={handleProjectReport}
              disabled={loading === "project" || !selectedProject}
              className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-3 py-2 text-xs font-medium hover:bg-ink-800 transition disabled:opacity-60 shrink-0"
            >
              {loading === "project" ? <Loader2 size={13} className="animate-spin" /> : <FileText size={13} />}
              PDF
            </button>
          </div>
        </ReportCard>

        <ReportCard
          icon={Building2}
          title="Municipality Report"
          description="Volume, approval rate, and fees collected per municipality."
        >
          <ExcelButton
            endpoint="/api/reports/municipality"
            filename="Municipality-Report.xlsx"
            sheetName="Municipalities"
            loadingKey="municipality"
            loading={loading}
            setLoading={setLoading}
          />
        </ReportCard>

        <ReportCard
          icon={Users}
          title="Engineer Performance Report"
          description="Projects assigned, approval rate, and correction rate per engineer."
        >
          <ExcelButton
            endpoint="/api/reports/engineer-performance"
            filename="Engineer-Performance-Report.xlsx"
            sheetName="Engineers"
            loadingKey="engineer"
            loading={loading}
            setLoading={setLoading}
          />
        </ReportCard>

        <ReportCard
          icon={CalendarCheck}
          title="Monthly Approval Report"
          description="Approvals granted per month over the last 12 months."
        >
          <ExcelButton
            endpoint="/api/reports/monthly-approvals"
            filename="Monthly-Approval-Report.xlsx"
            sheetName="Monthly Approvals"
            loadingKey="monthly"
            loading={loading}
            setLoading={setLoading}
          />
        </ReportCard>

        <ReportCard
          icon={Banknote}
          title="Revenue Report"
          description="Consultancy and municipality fee revenue, by month, last 12 months."
        >
          <ExcelButton
            endpoint="/api/reports/revenue"
            filename="Revenue-Report.xlsx"
            sheetName="Revenue"
            loadingKey="revenue"
            loading={loading}
            setLoading={setLoading}
          />
        </ReportCard>

        <ReportCard
          icon={AlertTriangle}
          title="Pending Projects Report"
          description="Every project not yet approved, with days since last update."
        >
          <ExcelButton
            endpoint="/api/reports/pending-projects"
            filename="Pending-Projects-Report.xlsx"
            sheetName="Pending Projects"
            loadingKey="pending"
            loading={loading}
            setLoading={setLoading}
          />
        </ReportCard>
      </div>
    </div>
  );
}
