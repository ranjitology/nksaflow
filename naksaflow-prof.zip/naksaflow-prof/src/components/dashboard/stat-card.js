import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

export default function StatCard({ label, value, delta, deltaLabel, icon: Icon, accent = "ink" }) {
  const positive = typeof delta === "number" ? delta >= 0 : null;

  return (
    <div className="card-surface corner-ticks p-5 flex flex-col gap-3 hover:shadow-sm transition-shadow">
      <div className="flex items-start justify-between">
        <span className="text-[13px] font-medium text-foreground/55">{label}</span>
        {Icon && (
          <div
            className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
              accent === "brass" ? "bg-brass-100 text-brass-700" : "bg-ink-100 text-ink-700"
            )}
          >
            <Icon size={15} strokeWidth={2} />
          </div>
        )}
      </div>

      <div className="font-display text-[28px] font-semibold leading-none font-tabular">
        {value}
      </div>

      {delta !== undefined && delta !== null && (
        <div className="flex items-center gap-1 text-xs">
          <span
            className={cn(
              "flex items-center gap-0.5 font-medium",
              positive ? "text-status-approved" : "text-status-correction"
            )}
          >
            {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
            {Math.abs(delta)}%
          </span>
          <span className="text-foreground/45">{deltaLabel}</span>
        </div>
      )}
    </div>
  );
}
