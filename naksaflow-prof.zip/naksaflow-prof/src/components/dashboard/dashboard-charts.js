"use client";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts";

const INK = "#2c5680";
const BRASS = "#c1823a";
const APPROVED = "#2f8f63";
const CORRECTION = "#c1524a";
const REVIEW = "#7d5fa6";

const tooltipStyle = {
  background: "var(--surface)",
  border: "1px solid var(--border)",
  borderRadius: 10,
  fontSize: 12.5,
};

export function MonthlySubmissionsChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <AreaChart data={data} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
        <defs>
          <linearGradient id="submissionsFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={INK} stopOpacity={0.35} />
            <stop offset="100%" stopColor={INK} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
        <XAxis dataKey="month" tick={{ fontSize: 11.5, fill: "var(--foreground)", opacity: 0.55 }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 11.5, fill: "var(--foreground)", opacity: 0.55 }} axisLine={false} tickLine={false} width={28} />
        <Tooltip contentStyle={tooltipStyle} />
        <Area type="monotone" dataKey="submissions" stroke={INK} strokeWidth={2} fill="url(#submissionsFill)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function ApprovalSuccessChart({ approved, corrected, pending }) {
  const data = [
    { name: "Approved", value: approved, color: APPROVED },
    { name: "Correction", value: corrected, color: CORRECTION },
    { name: "In progress", value: pending, color: REVIEW },
  ];
  const total = approved + corrected + pending || 1;
  const successRate = Math.round((approved / total) * 100);

  return (
    <div className="flex items-center gap-4">
      <ResponsiveContainer width={140} height={140}>
        <PieChart>
          <Pie data={data} dataKey="value" innerRadius={42} outerRadius={62} paddingAngle={2} strokeWidth={0}>
            {data.map((d, i) => (
              <Cell key={i} fill={d.color} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="flex-1 space-y-2.5">
        <div className="font-display text-2xl font-semibold font-tabular -mt-1">
          {successRate}%
          <span className="text-xs font-sans font-normal text-foreground/50 ml-1.5">success rate</span>
        </div>
        {data.map((d) => (
          <div key={d.name} className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-foreground/65">
              <span className="w-2 h-2 rounded-full" style={{ background: d.color }} />
              {d.name}
            </span>
            <span className="font-tabular font-medium">{d.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function MunicipalityWiseChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <BarChart data={data} layout="vertical" margin={{ top: 5, right: 16, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="var(--border)" />
        <XAxis type="number" tick={{ fontSize: 11, fill: "var(--foreground)", opacity: 0.55 }} axisLine={false} tickLine={false} />
        <YAxis
          type="category"
          dataKey="name"
          width={110}
          tick={{ fontSize: 11.5, fill: "var(--foreground)", opacity: 0.7 }}
          axisLine={false}
          tickLine={false}
        />
        <Tooltip contentStyle={tooltipStyle} />
        <Bar dataKey="count" fill={BRASS} radius={[0, 4, 4, 0]} barSize={14} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function RevenueChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <LineChart data={data} margin={{ top: 5, right: 10, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
        <XAxis dataKey="month" tick={{ fontSize: 11.5, fill: "var(--foreground)", opacity: 0.55 }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 11, fill: "var(--foreground)", opacity: 0.55 }} axisLine={false} tickLine={false} width={40} />
        <Tooltip contentStyle={tooltipStyle} formatter={(v) => "Rs. " + Number(v).toLocaleString("en-IN")} />
        <Legend wrapperStyle={{ fontSize: 11.5 }} />
        <Line type="monotone" dataKey="consultancy" name="Consultancy" stroke={INK} strokeWidth={2} dot={false} />
        <Line type="monotone" dataKey="municipality" name="Municipality fee" stroke={BRASS} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
