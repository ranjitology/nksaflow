"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { PlusCircle, Search, Loader2, Phone, MapPin } from "lucide-react";
import Modal from "@/components/ui/modal";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

export default function ClientsClient({ initialClients, municipalities }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [serverError, setServerError] = useState("");
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm();

  const filtered = initialClients.filter(
    (c) =>
      !query ||
      c.fullName.toLowerCase().includes(query.toLowerCase()) ||
      c.phone.includes(query)
  );

  async function onSubmit(data) {
    setServerError("");
    const res = await fetch("/api/clients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      setServerError("Could not save client. Check the required fields.");
      return;
    }
    reset();
    setOpen(false);
    router.refresh();
  }

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-semibold">Clients</h1>
          <p className="text-sm text-foreground/55 mt-0.5">Landowners and applicants you&apos;re filing Naksa Pass approvals for.</p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-4 py-2 text-sm font-medium hover:bg-ink-800 transition"
        >
          <PlusCircle size={15} />
          Add client
        </button>
      </div>

      <div className="relative max-w-sm">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground/40" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by name or phone…"
          className="w-full rounded-lg border border-border bg-surface pl-8 pr-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ink-500/30 focus:border-ink-500 transition"
        />
      </div>

      <div className="card-surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-foreground/45">
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Phone</th>
                <th className="px-4 py-3 font-medium">Municipality / Ward</th>
                <th className="px-4 py-3 font-medium">PAN</th>
                <th className="px-4 py-3 font-medium">Projects</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-foreground/45">
                    No clients found.
                  </td>
                </tr>
              )}
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-surface-2/60 transition">
                  <td className="px-4 py-3 font-medium">{c.fullName}</td>
                  <td className="px-4 py-3 font-tabular text-foreground/70">
                    <span className="flex items-center gap-1.5"><Phone size={12} />{c.phone}</span>
                  </td>
                  <td className="px-4 py-3 text-foreground/70">
                    <span className="flex items-center gap-1.5">
                      <MapPin size={12} />
                      {c.municipality?.name || "—"} {c.wardNumber ? `· Ward ${c.wardNumber}` : ""}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-tabular text-foreground/60">{c.panNumber || "—"}</td>
                  <td className="px-4 py-3 font-tabular">{c._count.projects}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Add client">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <input className={inputClass} placeholder="Full name" {...register("fullName", { required: true })} />
          <input className={inputClass} placeholder="Phone number" {...register("phone", { required: true })} />
          <input className={inputClass} placeholder="Email (optional)" {...register("email")} />
          <input className={inputClass} placeholder="Address" {...register("address")} />
          <div className="grid grid-cols-2 gap-3">
            <input className={inputClass} placeholder="Citizenship number" {...register("citizenshipNumber")} />
            <input className={inputClass} placeholder="PAN number" {...register("panNumber")} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <select className={inputClass} {...register("municipalityId")}>
              <option value="">Municipality…</option>
              {municipalities.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
            <input className={inputClass} placeholder="Ward number" {...register("wardNumber")} />
          </div>
          {serverError && <p className="text-xs text-status-correction">{serverError}</p>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {isSubmitting && <Loader2 size={14} className="animate-spin" />}
            Save client
          </button>
        </form>
      </Modal>
    </div>
  );
}
