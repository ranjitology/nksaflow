"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, FolderKanban, Users, Building2, CornerDownLeft, X } from "lucide-react";
import StageBadge from "@/components/projects/stage-badge";

export default function GlobalSearch() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ projects: [], clients: [], municipalities: [] });
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);

  const runSearch = useCallback(async (q) => {
    if (!q || q.trim().length < 2) {
      setResults({ projects: [], clients: [], municipalities: [] });
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setResults(data);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    function onKeyDown(e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen(true);
      }
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 10);
    else {
      setQuery("");
      setResults({ projects: [], clients: [], municipalities: [] });
    }
  }, [open]);

  function handleChange(value) {
    setQuery(value);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(value), 250);
  }

  function go(path) {
    setOpen(false);
    router.push(path);
  }

  const hasResults =
    results.projects.length > 0 || results.clients.length > 0 || results.municipalities.length > 0;

  return (
    <>
      <button onClick={() => setOpen(true)} className="flex-1 max-w-md relative text-left">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground/40" />
        <span className="block w-full rounded-lg border border-border bg-surface-2 pl-9 pr-3 py-2 text-sm text-foreground/40">
          Search project no., client, kitta...
        </span>
        <kbd className="hidden sm:flex absolute right-2.5 top-1/2 -translate-y-1/2 items-center gap-0.5 text-[10px] text-foreground/35 border border-border rounded px-1.5 py-0.5">
          ⌘K
        </kbd>
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-[12vh] p-4">
          <div className="absolute inset-0 bg-ink-950/40 backdrop-blur-[2px]" onClick={() => setOpen(false)} />
          <div className="relative w-full max-w-lg card-surface shadow-xl overflow-hidden animate-stamp-in">
            <div className="flex items-center gap-2.5 px-4 py-3 border-b border-border">
              <Search size={16} className="text-foreground/40 shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => handleChange(e.target.value)}
                placeholder="Search project no., client, kitta, municipality, phone..."
                className="flex-1 bg-transparent outline-none text-sm"
              />
              <button onClick={() => setOpen(false)} className="text-foreground/35 hover:text-foreground/70 shrink-0">
                <X size={15} />
              </button>
            </div>

            <div className="max-h-[60vh] overflow-y-auto">
              {loading && <p className="text-xs text-foreground/40 text-center py-6">Searching…</p>}

              {!loading && query.trim().length >= 2 && !hasResults && (
                <p className="text-xs text-foreground/40 text-center py-6">No matches for &quot;{query}&quot;.</p>
              )}

              {!loading && query.trim().length < 2 && (
                <p className="text-xs text-foreground/35 text-center py-6">
                  Type at least 2 characters to search across projects, clients, and municipalities.
                </p>
              )}

              {results.projects.length > 0 && (
                <ResultGroup icon={FolderKanban} label="Projects">
                  {results.projects.map((p) => (
                    <ResultRow key={p.id} onClick={() => go(`/projects/${p.id}`)}>
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="font-tabular text-[13px] font-medium">{p.projectNumber}</span>
                        <StageBadge stage={p.stage} size="sm" />
                      </div>
                      <p className="text-[11.5px] text-foreground/50 truncate">
                        {p.client?.fullName} · {p.municipality?.name}
                      </p>
                    </ResultRow>
                  ))}
                </ResultGroup>
              )}

              {results.clients.length > 0 && (
                <ResultGroup icon={Users} label="Clients">
                  {results.clients.map((c) => (
                    <ResultRow key={c.id} onClick={() => go(`/clients`)}>
                      <p className="text-[13px] font-medium">{c.fullName}</p>
                      <p className="text-[11.5px] text-foreground/50 font-tabular">{c.phone}</p>
                    </ResultRow>
                  ))}
                </ResultGroup>
              )}

              {results.municipalities.length > 0 && (
                <ResultGroup icon={Building2} label="Municipalities">
                  {results.municipalities.map((m) => (
                    <ResultRow key={m.id} onClick={() => go(`/municipalities`)}>
                      <p className="text-[13px] font-medium">{m.name}</p>
                    </ResultRow>
                  ))}
                </ResultGroup>
              )}
            </div>

            <div className="flex items-center gap-1.5 px-4 py-2 border-t border-border text-[10.5px] text-foreground/35">
              <CornerDownLeft size={11} />
              Select · Esc to close
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function ResultGroup({ icon: Icon, label, children }) {
  return (
    <div className="py-1.5">
      <p className="flex items-center gap-1.5 px-4 py-1 text-[10.5px] uppercase tracking-wide text-foreground/40 font-medium">
        <Icon size={11} />
        {label}
      </p>
      {children}
    </div>
  );
}

function ResultRow({ onClick, children }) {
  return (
    <button onClick={onClick} className="w-full text-left px-4 py-2 hover:bg-surface-2/60 transition">
      {children}
    </button>
  );
}
