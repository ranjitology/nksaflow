import { Construction } from "lucide-react";

export default function ComingSoon({ title, description }) {
  return (
    <div className="max-w-[1200px]">
      <h1 className="font-display text-xl font-semibold mb-1">{title}</h1>
      <p className="text-sm text-foreground/55 mb-6">{description}</p>
      <div className="card-surface p-14 flex flex-col items-center text-center gap-3 blueprint-grid">
        <div className="w-12 h-12 rounded-full bg-brass-100 text-brass-700 flex items-center justify-center">
          <Construction size={20} />
        </div>
        <p className="text-sm font-medium">This module lands in the next build phase</p>
        <p className="text-xs text-foreground/50 max-w-sm">
          The database schema already supports it — we&apos;ll wire up the UI once the
          foundation (auth, projects, clients) is confirmed working for you.
        </p>
      </div>
    </div>
  );
}
