"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { PlusCircle, Loader2, ShieldCheck, ShieldOff } from "lucide-react";
import Modal from "@/components/ui/modal";
import { ROLE_LABELS } from "@/lib/rbac";
import { formatDate } from "@/lib/utils";

const inputClass =
  "w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition";

const ROLE_BADGE = {
  ADMIN: "bg-ink-100 text-ink-700",
  ENGINEER: "bg-brass-100 text-brass-700",
  STAFF: "bg-status-review/10 text-status-review",
  CLIENT: "bg-status-new/10 text-status-new",
};

export default function UsersClient({ initialUsers }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [serverError, setServerError] = useState("");
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm({
    defaultValues: { role: "STAFF" },
  });

  async function onSubmit(data) {
    setServerError("");
    const res = await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json();
      setServerError(err.error?.formErrors?.[0] || err.error || "Could not create user.");
      return;
    }
    reset();
    setOpen(false);
    router.refresh();
  }

  async function toggleActive(user) {
    await fetch(`/api/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !user.isActive }),
    });
    router.refresh();
  }

  return (
    <div className="space-y-5 max-w-[1200px]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-semibold">Users</h1>
          <p className="text-sm text-foreground/55 mt-0.5">Manage Admin, Engineer, and Staff accounts.</p>
        </div>
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-4 py-2 text-sm font-medium hover:bg-ink-800 transition"
        >
          <PlusCircle size={15} />
          Add user
        </button>
      </div>

      <div className="card-surface overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-[11.5px] uppercase tracking-wide text-foreground/45">
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Last login</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {initialUsers.map((u) => (
                <tr key={u.id} className="hover:bg-surface-2/60 transition">
                  <td className="px-4 py-3 font-medium">{u.name}</td>
                  <td className="px-4 py-3 text-foreground/65">{u.email}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[11px] font-medium px-2 py-0.5 rounded-md ${ROLE_BADGE[u.role]}`}>
                      {ROLE_LABELS[u.role]}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-foreground/50 text-xs">
                    {u.lastLoginAt ? formatDate(u.lastLoginAt) : "Never"}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs font-medium ${u.isActive ? "text-status-approved" : "text-status-correction"}`}>
                      {u.isActive ? "Active" : "Deactivated"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => toggleActive(u)}
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-foreground/60 hover:text-foreground transition"
                    >
                      {u.isActive ? <ShieldOff size={13} /> : <ShieldCheck size={13} />}
                      {u.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Add user">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <input className={inputClass} placeholder="Full name" {...register("name", { required: true })} />
          <input type="email" className={inputClass} placeholder="Email" {...register("email", { required: true })} />
          <input type="password" className={inputClass} placeholder="Temporary password" {...register("password", { required: true })} />
          <select className={inputClass} {...register("role")}>
            <option value="ADMIN">Super Admin</option>
            <option value="ENGINEER">Engineer</option>
            <option value="STAFF">Office Staff</option>
          </select>
          <div className="grid grid-cols-2 gap-3">
            <input className={inputClass} placeholder="Phone" {...register("phone")} />
            <input className={inputClass} placeholder="License no. (engineer)" {...register("licenseNumber")} />
          </div>
          {serverError && <p className="text-xs text-status-correction">{serverError}</p>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
          >
            {isSubmitting && <Loader2 size={14} className="animate-spin" />}
            Create user
          </button>
        </form>
      </Modal>
    </div>
  );
}
