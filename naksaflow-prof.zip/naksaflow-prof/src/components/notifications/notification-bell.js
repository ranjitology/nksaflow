"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Bell, CheckCheck, FileWarning, CheckCircle2, Banknote, FolderPlus, Info } from "lucide-react";
import { formatDateTime } from "@/lib/utils";

const ICONS = {
  PROJECT_CREATED: FolderPlus,
  STATUS_CHANGED: Info,
  CORRECTION_REQUESTED: FileWarning,
  APPROVAL_GRANTED: CheckCircle2,
  PAYMENT_DUE: Banknote,
  GENERAL: Info,
};

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const ref = useRef(null);

  async function load() {
    const res = await fetch("/api/notifications");
    if (!res.ok) return;
    const data = await res.json();
    setNotifications(data.notifications || []);
    setUnreadCount(data.unreadCount || 0);
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  async function markRead(id) {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
    setUnreadCount((c) => Math.max(0, c - 1));
    await fetch(`/api/notifications/${id}`, { method: "PATCH" });
  }

  async function markAllRead() {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
    await fetch("/api/notifications/mark-all-read", { method: "POST" });
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="relative p-2 rounded-lg hover:bg-surface-2 text-foreground/60 hover:text-foreground transition"
        aria-label="Notifications"
      >
        <Bell size={17} />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 min-w-[15px] h-[15px] px-[3px] rounded-full bg-status-correction text-white text-[9px] font-bold flex items-center justify-center">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1.5 w-80 card-surface shadow-lg z-40 overflow-hidden">
          <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-border">
            <h4 className="text-sm font-semibold">Notifications</h4>
            {unreadCount > 0 && (
              <button
                onClick={markAllRead}
                className="flex items-center gap-1 text-xs text-ink-600 hover:text-ink-800"
              >
                <CheckCheck size={12} />
                Mark all read
              </button>
            )}
          </div>

          <div className="max-h-96 overflow-y-auto divide-y divide-border">
            {notifications.length === 0 && (
              <p className="text-xs text-foreground/45 text-center py-8">You&apos;re all caught up.</p>
            )}
            {notifications.map((n) => {
              const Icon = ICONS[n.type] || Info;
              const content = (
                <div
                  className={`flex gap-2.5 px-3.5 py-3 hover:bg-surface-2/60 transition cursor-pointer ${
                    !n.isRead ? "bg-ink-100/40" : ""
                  }`}
                  onClick={() => !n.isRead && markRead(n.id)}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                      !n.isRead ? "bg-ink-900 text-white" : "bg-surface-2 text-foreground/50"
                    }`}
                  >
                    <Icon size={13} />
                  </div>
                  <div className="min-w-0">
                    <p className={`text-[12.5px] leading-snug ${!n.isRead ? "font-semibold" : "font-medium"}`}>
                      {n.title}
                    </p>
                    <p className="text-[11.5px] text-foreground/55 leading-snug mt-0.5">{n.message}</p>
                    <p className="text-[10.5px] text-foreground/35 mt-1">{formatDateTime(n.createdAt)}</p>
                  </div>
                </div>
              );
              return n.project ? (
                <Link key={n.id} href={`/projects/${n.project.id}`} onClick={() => setOpen(false)}>
                  {content}
                </Link>
              ) : (
                <div key={n.id}>{content}</div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
