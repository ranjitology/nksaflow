"use client";

import { useEffect, useState } from "react";
import { Sun, Moon, LogOut, ChevronDown } from "lucide-react";
import { signOut } from "next-auth/react";
import { ROLE_LABELS } from "@/lib/rbac";
import NotificationBell from "@/components/notifications/notification-bell";
import GlobalSearch from "@/components/search/global-search";

export default function Topbar({ user }) {
  const [dark, setDark] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("naksaflow-theme", next ? "dark" : "light");
  }

  return (
    <header className="h-16 border-b border-border bg-surface/80 backdrop-blur sticky top-0 z-30 flex items-center gap-4 px-4 md:px-6">
      <GlobalSearch />

      <div className="flex items-center gap-1.5 ml-auto">
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg hover:bg-surface-2 text-foreground/60 hover:text-foreground transition"
          aria-label="Toggle theme"
        >
          {dark ? <Sun size={17} /> : <Moon size={17} />}
        </button>

        <NotificationBell />

        <div className="relative">
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-2 pl-2 pr-1.5 py-1.5 rounded-lg hover:bg-surface-2 transition"
          >
            <div className="w-7 h-7 rounded-full bg-ink-900 text-white flex items-center justify-center text-xs font-medium font-display">
              {user?.name?.charAt(0) || "U"}
            </div>
            <div className="text-left hidden sm:block">
              <div className="text-xs font-medium leading-tight">{user?.name}</div>
              <div className="text-[10.5px] text-foreground/50 leading-tight">
                {ROLE_LABELS[user?.role] || user?.role}
              </div>
            </div>
            <ChevronDown size={14} className="text-foreground/40" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-44 card-surface shadow-lg py-1 text-sm z-40">
              <button
                onClick={() => signOut({ callbackUrl: "/login" })}
                className="w-full flex items-center gap-2 px-3 py-2 text-status-correction hover:bg-surface-2 transition"
              >
                <LogOut size={14} />
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
