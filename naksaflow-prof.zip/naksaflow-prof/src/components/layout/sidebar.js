"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  FolderKanban,
  Users,
  Building2,
  FileStack,
  Wallet,
  BarChart3,
  UserCog,
  Settings,
  Compass,
  History,
} from "lucide-react";
import { canAccess } from "@/lib/rbac";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { section: "dashboard", href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { section: "projects", href: "/projects", label: "Projects", icon: FolderKanban },
  { section: "clients", href: "/clients", label: "Clients", icon: Users },
  { section: "municipalities", href: "/municipalities", label: "Municipalities", icon: Building2 },
  { section: "documents", href: "/documents", label: "Documents", icon: FileStack },
  { section: "payments", href: "/payments", label: "Payments", icon: Wallet },
  { section: "reports", href: "/reports", label: "Reports", icon: BarChart3 },
  { section: "activity", href: "/activity", label: "Activity Log", icon: History },
  { section: "users", href: "/users", label: "Users", icon: UserCog },
  { section: "settings", href: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar({ role }) {
  const pathname = usePathname();

  return (
    <aside className="hidden md:flex md:w-60 shrink-0 flex-col border-r border-border bg-surface h-screen sticky top-0">
      <div className="h-16 flex items-center gap-2.5 px-5 border-b border-border">
        <StampMark />
        <span className="font-display font-semibold text-[15px] tracking-tight">
          NaksaFlow Pro
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
        {NAV_ITEMS.filter((item) => canAccess(item.section, role)).map((item) => {
          const Icon = item.icon;
          const active = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13.5px] font-medium transition",
                active
                  ? "bg-ink-900 text-white"
                  : "text-foreground/65 hover:bg-surface-2 hover:text-foreground"
              )}
            >
              <Icon size={16} strokeWidth={2} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 border-t border-border">
        <a
          href="https://www.google.com/maps"
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] text-foreground/50 hover:bg-surface-2 hover:text-foreground/80 transition"
        >
          <Compass size={15} />
          Municipality directory
        </a>
      </div>
    </aside>
  );
}

function StampMark() {
  return (
    <svg width="26" height="26" viewBox="0 0 40 40" fill="none">
      <circle cx="20" cy="20" r="18" stroke="var(--brass-500)" strokeWidth="1.5" />
      <circle cx="20" cy="20" r="13" stroke="var(--brass-500)" strokeWidth="1" strokeDasharray="2 2" />
      <path
        d="M13 21l4.5 4.5L28 15"
        stroke="var(--brass-400)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
