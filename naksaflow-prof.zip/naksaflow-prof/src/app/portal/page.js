import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import StageBadge from "@/components/projects/stage-badge";
import ApprovalTimeline from "@/components/projects/approval-timeline";
import PortalPaymentsPanel from "@/components/portal/portal-payments-panel";
import { FileText, Download } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ClientPortalPage() {
  const session = await auth();

  const client = await prisma.client.findUnique({
    where: { id: session.user.clientId || "" },
    include: {
      projects: {
        include: {
          municipality: true,
          statusHistory: { orderBy: { changedAt: "asc" } },
          documents: { orderBy: { createdAt: "desc" } },
          payments: true,
        },
        orderBy: { updatedAt: "desc" },
      },
    },
  });

  if (!client) {
    return (
      <p className="text-sm text-foreground/55">
        Your account isn&apos;t linked to a client record yet. Please contact your consultancy.
      </p>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-xl font-semibold">Welcome, {client.fullName}</h1>
        <p className="text-sm text-foreground/55 mt-0.5">Track your Naksa Pass approval progress below.</p>
      </div>

      {client.projects.length === 0 && (
        <div className="card-surface p-10 text-center text-sm text-foreground/50">
          No projects on file yet.
        </div>
      )}

      {client.projects.map((p) => {
        return (
          <div key={p.id} className="card-surface p-5">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div>
                <span className="font-tabular font-semibold">{p.projectNumber}</span>
                <span className="text-sm text-foreground/55 ml-2">{p.municipality.name}</span>
              </div>
              <StageBadge stage={p.stage} />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <ApprovalTimeline currentStage={p.stage} statusHistory={p.statusHistory} />

              <div className="space-y-4">
                <PortalPaymentsPanel payments={p.payments} />

                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-2">
                    Documents
                  </h4>
                  {p.documents.length === 0 ? (
                    <p className="text-xs text-foreground/45">No documents shared yet.</p>
                  ) : (
                    <div className="space-y-1.5">
                      {p.documents.slice(0, 5).map((d) => (
                        <a
                          key={d.id}
                          href={d.fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center justify-between text-xs hover:bg-surface-2/60 rounded-md px-2 py-1.5 -mx-2 transition"
                        >
                          <span className="flex items-center gap-1.5 truncate">
                            <FileText size={12} className="text-ink-600 shrink-0" />
                            {d.fileName}
                          </span>
                          <Download size={12} className="text-foreground/35 shrink-0" />
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
