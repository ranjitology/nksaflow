import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { signOut } from "@/lib/auth";
import { LogOut } from "lucide-react";

export default async function PortalLayout({ children }) {
  const session = await auth();
  if (!session?.user) redirect("/login");
  if (session.user.role !== "CLIENT") redirect("/dashboard");

  return (
    <div className="min-h-screen bg-background">
      <header className="h-16 border-b border-border bg-surface flex items-center justify-between px-6">
        <div className="flex items-center gap-2.5">
          <svg width="26" height="26" viewBox="0 0 40 40" fill="none">
            <circle cx="20" cy="20" r="18" stroke="var(--brass-500)" strokeWidth="1.5" />
            <path d="M13 21l4.5 4.5L28 15" stroke="var(--brass-400)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-display font-semibold">NaksaFlow Pro</span>
          <span className="text-xs text-foreground/40 ml-1">Client Portal</span>
        </div>
        <form
          action={async () => {
            "use server";
            await signOut({ redirectTo: "/login" });
          }}
        >
          <button className="flex items-center gap-1.5 text-sm text-foreground/60 hover:text-status-correction transition">
            <LogOut size={15} />
            Sign out
          </button>
        </form>
      </header>
      <main className="p-6 max-w-4xl mx-auto">{children}</main>
    </div>
  );
}
