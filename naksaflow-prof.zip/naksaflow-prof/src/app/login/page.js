import LoginForm from "./login-form";

export const metadata = {
  title: "Sign in — NaksaFlow Pro",
};

export default function LoginPage() {
  return (
    <div className="min-h-screen w-full flex items-stretch bg-background">
      {/* Left: brand / blueprint panel */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-ink-950 text-ink-100 blueprint-grid overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-ink-950/95 via-ink-900/90 to-ink-950/95" />
        <div className="relative z-10 flex flex-col justify-between p-14 w-full">
          <div className="flex items-center gap-3">
            <StampMark />
            <span className="font-display font-semibold text-lg tracking-tight">
              NaksaFlow Pro
            </span>
          </div>

          <div className="max-w-md">
            <p className="text-sm uppercase tracking-[0.2em] text-brass-400 mb-4 font-tabular">
              Municipality Approval System
            </p>
            <h1 className="font-display text-4xl font-semibold leading-tight mb-4">
              From site survey to
              <br />
              stamped approval.
            </h1>
            <p className="text-ink-400 text-[15px] leading-relaxed">
              Track every Naksa Pass file — drawings, revisions, municipality
              correspondence, and client sign-off — in one drafting-table view.
            </p>
          </div>

          <div className="flex gap-8 font-tabular text-sm text-ink-400">
            <div>
              <div className="text-2xl text-ink-100 font-display">11</div>
              stage workflow
            </div>
            <div>
              <div className="text-2xl text-ink-100 font-display">4</div>
              role types
            </div>
            <div>
              <div className="text-2xl text-ink-100 font-display">100%</div>
              audit trail
            </div>
          </div>
        </div>
      </div>

      {/* Right: form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="lg:hidden flex items-center gap-2 mb-10 justify-center">
            <StampMark small />
            <span className="font-display font-semibold text-lg">NaksaFlow Pro</span>
          </div>
          <LoginForm />
        </div>
      </div>
    </div>
  );
}

function StampMark({ small }) {
  const size = small ? 32 : 40;
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <circle cx="20" cy="20" r="18" stroke="var(--brass-500)" strokeWidth="1.5" />
      <circle cx="20" cy="20" r="13" stroke="var(--brass-500)" strokeWidth="1" strokeDasharray="2 2" />
      <path d="M13 21l4.5 4.5L28 15" stroke="var(--brass-400)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
