"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { Eye, EyeOff, Loader2 } from "lucide-react";

const schema = z.object({
  email: z.string().email("Enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

export default function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(schema) });

  const onSubmit = async (data) => {
    setServerError("");
    setSubmitting(true);
    const res = await signIn("credentials", {
      email: data.email,
      password: data.password,
      redirect: false,
    });
    setSubmitting(false);

    if (res?.error) {
      setServerError("Incorrect email or password. Please try again.");
      return;
    }
    router.push(params.get("callbackUrl") || "/dashboard");
    router.refresh();
  };

  return (
    <div>
      <h2 className="font-display text-2xl font-semibold mb-1">Sign in</h2>
      <p className="text-sm text-foreground/60 mb-8">
        Enter your credentials to open your workspace.
      </p>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1.5">Email</label>
          <input
            type="email"
            autoComplete="email"
            placeholder="you@consultancy.com"
            className="w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition"
            {...register("email")}
          />
          {errors.email && (
            <p className="text-xs text-status-correction mt-1">{errors.email.message}</p>
          )}
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="block text-sm font-medium">Password</label>
            <a href="/forgot-password" className="text-xs text-ink-500 hover:text-ink-600">
              Forgot password?
            </a>
          </div>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              className="w-full rounded-lg border border-border bg-surface px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ink-500/40 focus:border-ink-500 transition pr-10"
              {...register("password")}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground/40 hover:text-foreground/70"
              tabIndex={-1}
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
          {errors.password && (
            <p className="text-xs text-status-correction mt-1">{errors.password.message}</p>
          )}
        </div>

        {serverError && (
          <div className="rounded-lg bg-status-correction/10 border border-status-correction/30 px-3 py-2 text-sm text-status-correction">
            {serverError}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full flex items-center justify-center gap-2 rounded-lg bg-ink-900 text-white py-2.5 text-sm font-medium hover:bg-ink-800 transition disabled:opacity-60"
        >
          {submitting && <Loader2 size={15} className="animate-spin" />}
          Sign in
        </button>
      </form>

      <div className="mt-8 pt-6 border-t border-border">
        <p className="text-xs font-medium text-foreground/50 mb-2 uppercase tracking-wide">
          Demo accounts
        </p>
        <div className="grid grid-cols-2 gap-2 text-xs font-tabular text-foreground/60">
          <div>admin@naksaflow.com</div>
          <div>engineer@naksaflow.com</div>
          <div>staff@naksaflow.com</div>
          <div>client@naksaflow.com</div>
        </div>
        <p className="text-xs text-foreground/40 mt-2">Password for all: password123</p>
      </div>
    </div>
  );
}
