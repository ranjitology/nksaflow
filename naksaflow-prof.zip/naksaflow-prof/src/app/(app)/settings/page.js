import { prisma } from "@/lib/prisma";
import SettingsClient from "@/components/settings/settings-client";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  let settings = await prisma.companySetting.findUnique({ where: { id: "singleton" } });
  if (!settings) {
    settings = await prisma.companySetting.create({
      data: { id: "singleton", companyName: "NaksaFlow Pro" },
    });
  }
  return <SettingsClient initialSettings={settings} />;
}
