import { prisma } from "@/lib/prisma";
import ReportsClient from "@/components/reports/reports-client";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  const projects = await prisma.naksaProject.findMany({
    select: { id: true, projectNumber: true, client: { select: { fullName: true } } },
    orderBy: { updatedAt: "desc" },
  });

  return <ReportsClient projects={projects} />;
}
