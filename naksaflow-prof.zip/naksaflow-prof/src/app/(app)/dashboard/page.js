import { prisma } from "@/lib/prisma";
import StatCard from "@/components/dashboard/stat-card";
import {
  MonthlySubmissionsChart,
  ApprovalSuccessChart,
  MunicipalityWiseChart,
  RevenueChart,
} from "@/components/dashboard/dashboard-charts";
import StageBadge from "@/components/projects/stage-badge";
import Link from "next/link";
import { formatCurrency, formatDate } from "@/lib/utils";
import {
  FolderKanban,
  PlusCircle,
  Clock,
  Eye,
  CheckCircle2,
  AlertTriangle,
  Banknote,
} from "lucide-react";

export const dynamic = "force-dynamic";

async function getDashboardData() {
  const [
    totalProjects,
    byStage,
    recentProjects,
    projectsWithDates,
    payments,
    municipalities,
  ] = await Promise.all([
    prisma.naksaProject.count(),
    prisma.naksaProject.groupBy({ by: ["stage"], _count: { _all: true } }),
    prisma.naksaProject.findMany({
      take: 6,
      orderBy: { updatedAt: "desc" },
      include: { client: true, municipality: true },
    }),
    prisma.naksaProject.findMany({
      select: { submissionDate: true, municipalityId: true, municipality: { select: { name: true } } },
    }),
    prisma.payment.findMany(),
    prisma.municipality.findMany({ include: { _count: { select: { projects: true } } } }),
  ]);

  const stageCounts = Object.fromEntries(byStage.map((s) => [s.stage, s._count._all]));

  const newCount = stageCounts.NEW_INQUIRY || 0;
  const pendingCount =
    (stageCounts.SITE_SURVEY || 0) +
    (stageCounts.ARCHITECTURAL_DRAWING || 0) +
    (stageCounts.STRUCTURAL_DRAWING || 0) +
    (stageCounts.DOCUMENT_PREPARATION || 0);
  const underReviewCount =
    (stageCounts.MUNICIPALITY_SUBMISSION || 0) +
    (stageCounts.UNDER_REVIEW || 0) +
    (stageCounts.RESUBMISSION || 0);
  const approvedCount = stageCounts.APPROVED || 0;
  const correctionCount = stageCounts.CORRECTION_REQUIRED || 0;
  const completedCount = stageCounts.COMPLETED || 0;

  // Monthly submissions for the last 6 months
  const now = new Date();
  const months = Array.from({ length: 6 }).map((_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    return { key: `${d.getFullYear()}-${d.getMonth()}`, month: d.toLocaleString("en", { month: "short" }) };
  });
  const monthlyMap = Object.fromEntries(months.map((m) => [m.key, 0]));
  projectsWithDates.forEach((p) => {
    if (!p.submissionDate) return;
    const d = new Date(p.submissionDate);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    if (key in monthlyMap) monthlyMap[key] += 1;
  });
  const monthlySubmissions = months.map((m) => ({ month: m.month, submissions: monthlyMap[m.key] }));

  // Municipality-wise counts
  const municipalityWise = municipalities
    .map((m) => ({ name: m.name, count: m._count.projects }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  // Revenue
  const consultancyRevenue = payments
    .filter((p) => p.type === "CONSULTANCY_FEE" && p.status === "PAID")
    .reduce((s, p) => s + p.amount, 0);
  const municipalityFees = payments
    .filter((p) => p.type === "MUNICIPALITY_FEE")
    .reduce((s, p) => s + p.amount, 0);
  const outstanding = payments
    .filter((p) => p.status === "PENDING" || p.status === "PARTIAL" || p.status === "OVERDUE")
    .reduce((s, p) => s + p.amount, 0);

  const revenueByMonth = months.map((m) => ({ month: m.month, consultancy: 0, municipality: 0 }));
  payments.forEach((p) => {
    const d = new Date(p.createdAt);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    const idx = months.findIndex((m) => m.key === key);
    if (idx === -1) return;
    if (p.type === "CONSULTANCY_FEE") revenueByMonth[idx].consultancy += p.amount;
    if (p.type === "MUNICIPALITY_FEE") revenueByMonth[idx].municipality += p.amount;
  });

  return {
    totalProjects,
    newCount,
    pendingCount,
    underReviewCount,
    approvedCount,
    correctionCount,
    completedCount,
    monthlySubmissions,
    municipalityWise,
    consultancyRevenue,
    municipalityFees,
    outstanding,
    revenueByMonth,
    recentProjects,
  };
}

export default async function DashboardPage() {
  const data = await getDashboardData();

  return (
    <div className="space-y-6 max-w-[1400px]">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-xl font-semibold">Dashboard</h1>
          <p className="text-sm text-foreground/55 mt-0.5">
            Overview of every Naksa Pass file across your consultancy.
          </p>
        </div>
        <Link
          href="/projects/new"
          className="flex items-center gap-1.5 rounded-lg bg-ink-900 text-white px-4 py-2 text-sm font-medium hover:bg-ink-800 transition"
        >
          <PlusCircle size={15} />
          New project
        </Link>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatCard label="Total Projects" value={data.totalProjects} icon={FolderKanban} />
        <StatCard label="New" value={data.newCount} icon={PlusCircle} />
        <StatCard label="Pending" value={data.pendingCount} icon={Clock} />
        <StatCard label="Under Review" value={data.underReviewCount} icon={Eye} accent="brass" />
        <StatCard label="Correction" value={data.correctionCount} icon={AlertTriangle} accent="brass" />
        <StatCard label="Approved" value={data.approvedCount} icon={CheckCircle2} />
      </div>

      {/* Revenue cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard
          label="Consultancy Revenue"
          value={formatCurrency(data.consultancyRevenue)}
          icon={Banknote}
          accent="brass"
        />
        <StatCard
          label="Municipality Fees Collected"
          value={formatCurrency(data.municipalityFees)}
          icon={Banknote}
        />
        <StatCard
          label="Outstanding Payments"
          value={formatCurrency(data.outstanding)}
          icon={Banknote}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card-surface p-5">
          <h3 className="text-sm font-semibold mb-4">Monthly Project Submissions</h3>
          <MonthlySubmissionsChart data={data.monthlySubmissions} />
        </div>
        <div className="card-surface p-5">
          <h3 className="text-sm font-semibold mb-4">Approval Success Rate</h3>
          <ApprovalSuccessChart
            approved={data.approvedCount + data.completedCount}
            corrected={data.correctionCount}
            pending={data.pendingCount + data.underReviewCount}
          />
        </div>
        <div className="card-surface p-5">
          <h3 className="text-sm font-semibold mb-4">Municipality Wise Projects</h3>
          <MunicipalityWiseChart data={data.municipalityWise} />
        </div>
        <div className="card-surface p-5">
          <h3 className="text-sm font-semibold mb-4">Revenue Analytics</h3>
          <RevenueChart data={data.revenueByMonth} />
        </div>
      </div>

      {/* Recent projects */}
      <div className="card-surface p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold">Recently updated projects</h3>
          <Link href="/projects" className="text-xs text-ink-600 hover:text-ink-800 font-medium">
            View all →
          </Link>
        </div>
        <div className="divide-y divide-border">
          {data.recentProjects.length === 0 && (
            <p className="text-sm text-foreground/50 py-6 text-center">
              No projects yet. Create your first Naksa Pass file to get started.
            </p>
          )}
          {data.recentProjects.map((p) => (
            <Link
              key={p.id}
              href={`/projects/${p.id}`}
              className="flex items-center justify-between py-3 hover:bg-surface-2/50 -mx-2 px-2 rounded-lg transition"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-tabular text-[13px] font-medium">{p.projectNumber}</span>
                  <StageBadge stage={p.stage} size="sm" />
                </div>
                <p className="text-xs text-foreground/55 mt-0.5 truncate">
                  {p.client.fullName} · {p.municipality.name}
                </p>
              </div>
              <span className="text-xs text-foreground/40 shrink-0 ml-3">{formatDate(p.updatedAt)}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
