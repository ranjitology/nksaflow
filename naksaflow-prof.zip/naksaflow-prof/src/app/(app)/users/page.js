import { prisma } from "@/lib/prisma";
import UsersClient from "@/components/users/users-client";

export const dynamic = "force-dynamic";

export default async function UsersPage() {
  const users = await prisma.user.findMany({
    select: {
      id: true, name: true, email: true, role: true, phone: true,
      licenseNumber: true, isActive: true, lastLoginAt: true, createdAt: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return <UsersClient initialUsers={users} />;
}
