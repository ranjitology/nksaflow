import { prisma } from "@/lib/prisma";
import PaymentsClient from "@/components/payments/payments-client";

export const dynamic = "force-dynamic";

export default async function PaymentsPage() {
  const [payments, projects] = await Promise.all([
    prisma.payment.findMany({
      include: {
        project: { select: { id: true, projectNumber: true } },
        client: { select: { id: true, fullName: true } },
        invoice: true,
      },
      orderBy: { createdAt: "desc" },
    }),
    prisma.naksaProject.findMany({
      select: { id: true, projectNumber: true, client: { select: { fullName: true } } },
      orderBy: { updatedAt: "desc" },
    }),
  ]);

  return <PaymentsClient initialPayments={payments} projects={projects} />;
}
