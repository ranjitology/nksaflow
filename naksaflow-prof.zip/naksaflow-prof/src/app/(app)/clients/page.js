import { prisma } from "@/lib/prisma";
import ClientsClient from "@/components/clients/clients-client";

export const dynamic = "force-dynamic";

export default async function ClientsPage() {
  const [clients, municipalities] = await Promise.all([
    prisma.client.findMany({
      include: { municipality: true, _count: { select: { projects: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.municipality.findMany({ orderBy: { name: "asc" } }),
  ]);

  return <ClientsClient initialClients={clients} municipalities={municipalities} />;
}
