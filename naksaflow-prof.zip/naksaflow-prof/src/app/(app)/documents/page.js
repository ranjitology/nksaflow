import { prisma } from "@/lib/prisma";
import DocumentsClient from "@/components/documents/documents-client";

export const dynamic = "force-dynamic";

export default async function DocumentsPage() {
  const documents = await prisma.projectDocument.findMany({
    include: {
      project: { select: { id: true, projectNumber: true } },
      uploadedBy: { select: { name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 300,
  });

  return <DocumentsClient documents={documents} />;
}
