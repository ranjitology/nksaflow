import ProjectForm from "@/components/projects/project-form";

export default function NewProjectPage() {
  return (
    <div className="max-w-3xl">
      <h1 className="font-display text-xl font-semibold mb-1">New Naksa Pass project</h1>
      <p className="text-sm text-foreground/55 mb-6">
        Capture the land, client, and team details to open a new approval file.
      </p>
      <ProjectForm />
    </div>
  );
}
