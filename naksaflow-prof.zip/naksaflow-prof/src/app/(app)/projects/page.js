import ProjectsClient from "@/components/projects/projects-client";

export default async function ProjectsPage({ searchParams }) {
  const params = await searchParams;
  return <ProjectsClient initialQuery={params?.q || ""} />;
}
