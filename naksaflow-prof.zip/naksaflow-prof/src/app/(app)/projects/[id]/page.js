import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import StageBadge from "@/components/projects/stage-badge";
import ApprovalTimeline from "@/components/projects/approval-timeline";
import StageUpdater from "@/components/projects/stage-updater";
import DocumentManager from "@/components/projects/document-manager";
import SiteSurveyManager from "@/components/projects/site-survey-manager";
import DrawingRevisions from "@/components/projects/drawing-revisions";
import { formatCurrency, formatDate, humanizeEnum } from "@/lib/utils";
import { MapPin, Ruler, Building2, User, Calendar } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ProjectDetailPage({ params }) {
  const { id } = await params;

  const project = await prisma.naksaProject.findUnique({
    where: { id },
    include: {
      client: true,
      municipality: true,
      engineer: true,
      architect: true,
      surveyor: true,
      statusHistory: { orderBy: { changedAt: "asc" } },
      documents: { orderBy: { createdAt: "desc" } },
      payments: true,
      siteSurveys: {
        orderBy: { surveyDate: "desc" },
        include: { engineer: { select: { name: true } }, photos: true },
      },
      revisions: {
        orderBy: { revisionNumber: "desc" },
        include: { engineer: { select: { name: true } } },
      },
    },
  });

  if (!project) notFound();

  const totalPaid = project.payments
    .filter((p) => p.status === "PAID")
    .reduce((s, p) => s + p.amount, 0);
  const totalDue = project.payments
    .filter((p) => p.status !== "PAID")
    .reduce((s, p) => s + p.amount, 0);

  return (
    <div className="max-w-[1200px] space-y-6">
      {/* Header */}
      <div className="card-surface p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <h1 className="font-display text-xl font-semibold font-tabular">{project.projectNumber}</h1>
              <StageBadge stage={project.stage} />
            </div>
            <p className="text-sm text-foreground/60">
              {project.client.fullName} · {project.municipality.name} · Ward {project.wardNumber}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-foreground/45 mb-1">Overall progress</p>
            <div className="w-40 h-2 rounded-full bg-surface-2 overflow-hidden">
              <div
                className="h-full bg-ink-700 transition-all"
                style={{ width: `${project.progressPercent}%` }}
              />
            </div>
            <p className="text-xs font-tabular text-foreground/50 mt-1">{project.progressPercent}%</p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-6 border-t border-border">
          <InfoItem icon={MapPin} label="Kitta Number" value={project.kittaNumber} />
          <InfoItem icon={Ruler} label="Land Area" value={`${project.landArea} ${project.landAreaUnit}`} />
          <InfoItem icon={Building2} label="Building Type" value={`${humanizeEnum(project.buildingType)} · ${project.numberOfFloors} floors`} />
          <InfoItem icon={Calendar} label="Estimated Cost" value={formatCurrency(project.estimatedCost)} />
        </div>

        <div className="grid sm:grid-cols-3 gap-4 mt-4">
          <InfoItem icon={User} label="Engineer" value={project.engineer?.name || "Unassigned"} />
          <InfoItem icon={User} label="Architect" value={project.architect?.name || "Unassigned"} />
          <InfoItem icon={User} label="Surveyor" value={project.surveyor?.name || "Unassigned"} />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left: timeline + documents */}
        <div className="lg:col-span-2 space-y-6">
          <div className="card-surface p-5">
            <h3 className="text-sm font-semibold mb-4">Approval Timeline</h3>
            <ApprovalTimeline currentStage={project.stage} statusHistory={project.statusHistory} />
          </div>

          <DocumentManager projectId={project.id} documents={project.documents} />

          <SiteSurveyManager project={project} surveys={project.siteSurveys} />

          <DrawingRevisions projectId={project.id} revisions={project.revisions} />
        </div>

        {/* Right: stage updater, dates, payments */}
        <div className="space-y-6">
          <StageUpdater projectId={project.id} currentStage={project.stage} />

          <div className="card-surface p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-3">
              Key dates
            </h3>
            <dl className="space-y-2 text-sm">
              <Row label="Start" value={formatDate(project.startDate)} />
              <Row label="Submission" value={formatDate(project.submissionDate)} />
              <Row label="Approval" value={formatDate(project.approvalDate)} />
              <Row label="Completion" value={formatDate(project.completionDate)} />
            </dl>
          </div>

          <div className="card-surface p-5">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-foreground/45 mb-3">
              Payments
            </h3>
            <dl className="space-y-2 text-sm">
              <Row label="Paid" value={formatCurrency(totalPaid)} valueClass="text-status-approved font-medium" />
              <Row label="Outstanding" value={formatCurrency(totalDue)} valueClass="text-status-correction font-medium" />
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoItem({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2.5">
      <div className="w-8 h-8 rounded-lg bg-ink-100 text-ink-700 flex items-center justify-center shrink-0">
        <Icon size={14} />
      </div>
      <div className="min-w-0">
        <p className="text-[11px] text-foreground/45">{label}</p>
        <p className="text-[13.5px] font-medium truncate">{value}</p>
      </div>
    </div>
  );
}

function Row({ label, value, valueClass }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-foreground/55">{label}</dt>
      <dd className={`font-tabular ${valueClass || ""}`}>{value}</dd>
    </div>
  );
}
