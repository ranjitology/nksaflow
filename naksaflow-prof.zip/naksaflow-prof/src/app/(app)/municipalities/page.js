import { prisma } from "@/lib/prisma";
import MunicipalitiesClient from "@/components/municipalities/municipalities-client";

export const dynamic = "force-dynamic";

export default async function MunicipalitiesPage() {
  const municipalities = await prisma.municipality.findMany({
    include: { _count: { select: { projects: true, clients: true } } },
    orderBy: { name: "asc" },
  });

  return <MunicipalitiesClient initialMunicipalities={municipalities} />;
}
