import { prisma } from "@/lib/prisma";
import ActivityClient from "@/components/activity/activity-client";

export const dynamic = "force-dynamic";

export default async function ActivityLogPage() {
  const logs = await prisma.activityLog.findMany({
    include: {
      user: { select: { name: true, role: true } },
      project: { select: { id: true, projectNumber: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  const modules = [...new Set(logs.map((l) => l.module))].sort();

  return <ActivityClient logs={logs} modules={modules} />;
}
