import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

const SETTINGS_ID = "singleton";

export async function GET() {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  let settings = await prisma.companySetting.findUnique({ where: { id: SETTINGS_ID } });
  if (!settings) {
    settings = await prisma.companySetting.create({
      data: { id: SETTINGS_ID, companyName: "NaksaFlow Pro" },
    });
  }
  return NextResponse.json({ settings });
}

export async function PUT(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Only an admin can edit company settings" }, { status: 403 });
  }

  const contentType = request.headers.get("content-type") || "";
  let data = {};

  if (contentType.includes("multipart/form-data")) {
    const formData = await request.formData();
    const fields = ["companyName", "address", "phone", "email", "panNumber", "engineerLicenseNo"];
    for (const f of fields) {
      const v = formData.get(f);
      if (v !== null) data[f] = v;
    }

    for (const key of ["logo", "signature", "stamp"]) {
      const file = formData.get(key);
      if (file && typeof file !== "string" && file.size > 0) {
        const uploadDir = path.join(process.cwd(), "public", "uploads", "company");
        await mkdir(uploadDir, { recursive: true });
        const ext = (file.name.split(".").pop() || "png").toLowerCase();
        const safeName = `${key}-${Date.now()}.${ext}`;
        const buffer = Buffer.from(await file.arrayBuffer());
        await writeFile(path.join(uploadDir, safeName), buffer);
        const urlField =
          key === "logo" ? "logoUrl" : key === "signature" ? "signatureImageUrl" : "stampImageUrl";
        data[urlField] = `/uploads/company/${safeName}`;
      }
    }
  } else {
    data = await request.json();
  }

  const settings = await prisma.companySetting.upsert({
    where: { id: SETTINGS_ID },
    update: data,
    create: { id: SETTINGS_ID, ...data },
  });

  return NextResponse.json({ settings });
}
