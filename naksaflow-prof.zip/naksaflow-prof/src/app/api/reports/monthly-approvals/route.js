import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const projects = await prisma.naksaProject.findMany({
    where: { approvalDate: { not: null } },
    select: { approvalDate: true, projectNumber: true, municipality: { select: { name: true } } },
  });

  const now = new Date();
  const months = Array.from({ length: 12 }).map((_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (11 - i), 1);
    return { key: `${d.getFullYear()}-${d.getMonth()}`, label: d.toLocaleString("en", { month: "short", year: "2-digit" }) };
  });

  const counts = Object.fromEntries(months.map((m) => [m.key, 0]));
  projects.forEach((p) => {
    const d = new Date(p.approvalDate);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    if (key in counts) counts[key] += 1;
  });

  const rows = months.map((m) => ({ Month: m.label, "Approvals Granted": counts[m.key] }));

  return NextResponse.json({ rows });
}
