import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const engineers = await prisma.user.findMany({
    where: { role: { in: ["ENGINEER", "ADMIN"] } },
    include: { engineeredProjects: true },
  });

  const rows = engineers
    .filter((e) => e.engineeredProjects.length > 0)
    .map((e) => {
      const total = e.engineeredProjects.length;
      const approved = e.engineeredProjects.filter((p) => p.stage === "APPROVED" || p.stage === "COMPLETED").length;
      const correction = e.engineeredProjects.filter((p) => p.stage === "CORRECTION_REQUIRED").length;
      const active = total - approved;

      return {
        "Engineer": e.name,
        "License No.": e.licenseNumber || "—",
        "Total Assigned": total,
        "Approved / Completed": approved,
        "Active": active,
        "Correction Requests": correction,
        "Approval Rate (%)": total ? Math.round((approved / total) * 100) : 0,
      };
    });

  return NextResponse.json({ rows });
}
