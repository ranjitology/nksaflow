import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const payments = await prisma.payment.findMany({ where: { status: "PAID" } });

  const now = new Date();
  const months = Array.from({ length: 12 }).map((_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (11 - i), 1);
    return { key: `${d.getFullYear()}-${d.getMonth()}`, label: d.toLocaleString("en", { month: "short", year: "2-digit" }) };
  });

  const table = Object.fromEntries(
    months.map((m) => [m.key, { consultancy: 0, municipality: 0, other: 0 }])
  );

  payments.forEach((p) => {
    const date = p.paidAt || p.createdAt;
    const d = new Date(date);
    const key = `${d.getFullYear()}-${d.getMonth()}`;
    if (!(key in table)) return;
    if (p.type === "CONSULTANCY_FEE") table[key].consultancy += p.amount;
    else if (p.type === "MUNICIPALITY_FEE") table[key].municipality += p.amount;
    else table[key].other += p.amount;
  });

  const rows = months.map((m) => ({
    Month: m.label,
    "Consultancy Revenue": table[m.key].consultancy,
    "Municipality Fees": table[m.key].municipality,
    "Other": table[m.key].other,
    "Total": table[m.key].consultancy + table[m.key].municipality + table[m.key].other,
  }));

  return NextResponse.json({ rows });
}
