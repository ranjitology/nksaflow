import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { humanizeEnum } from "@/lib/utils";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const projects = await prisma.naksaProject.findMany({
    where: { stage: { notIn: ["APPROVED", "COMPLETED"] } },
    include: { client: true, municipality: true, engineer: true },
    orderBy: { updatedAt: "asc" },
  });

  const now = Date.now();
  const rows = projects.map((p) => ({
    "Project No.": p.projectNumber,
    "Client": p.client.fullName,
    "Municipality": p.municipality.name,
    "Stage": humanizeEnum(p.stage),
    "Engineer": p.engineer?.name || "Unassigned",
    "Days Since Update": Math.floor((now - new Date(p.updatedAt).getTime()) / (1000 * 60 * 60 * 24)),
  }));

  return NextResponse.json({ rows });
}
