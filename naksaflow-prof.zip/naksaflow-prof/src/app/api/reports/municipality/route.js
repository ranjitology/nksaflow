import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const municipalities = await prisma.municipality.findMany({
    include: { projects: { include: { payments: true } } },
  });

  const rows = municipalities.map((m) => {
    const total = m.projects.length;
    const approved = m.projects.filter((p) => p.stage === "APPROVED" || p.stage === "COMPLETED").length;
    const correction = m.projects.filter((p) => p.stage === "CORRECTION_REQUIRED").length;
    const revenue = m.projects
      .flatMap((p) => p.payments)
      .filter((pm) => pm.type === "MUNICIPALITY_FEE" && pm.status === "PAID")
      .reduce((s, pm) => s + pm.amount, 0);

    return {
      "Municipality": m.name,
      "Total Projects": total,
      "Approved": approved,
      "Correction Required": correction,
      "Success Rate (%)": total ? Math.round((approved / total) * 100) : 0,
      "Municipality Fees Collected": revenue,
    };
  });

  return NextResponse.json({ rows });
}
