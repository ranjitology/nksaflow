import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/project-helpers";

export async function PATCH(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const body = await request.json();

  const data = {};
  if (body.status) {
    data.status = body.status;
    if (body.status === "PAID") data.paidAt = new Date();
  }
  if (body.method) data.method = body.method;

  const payment = await prisma.payment.update({
    where: { id },
    data,
    include: { project: { select: { projectNumber: true } } },
  });

  await logActivity({
    userId: session.user.id,
    projectId: payment.projectId,
    action: "updated",
    module: "Payment",
    details: `Payment marked ${payment.status} for ${payment.project.projectNumber}`,
  });

  return NextResponse.json({ payment });
}
