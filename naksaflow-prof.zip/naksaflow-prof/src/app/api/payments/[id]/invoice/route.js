import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function generateInvoiceNumber() {
  const year = new Date().getFullYear();
  const count = await prisma.invoice.count({
    where: { invoiceNumber: { startsWith: `INV-${year}-` } },
  });
  return `INV-${year}-${String(count + 1).padStart(5, "0")}`;
}

export async function POST(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;

  const payment = await prisma.payment.findUnique({
    where: { id },
    include: {
      project: { include: { municipality: true } },
      client: true,
      invoice: true,
    },
  });
  if (!payment) return NextResponse.json({ error: "Payment not found" }, { status: 404 });

  const isStaffSide = ["ADMIN", "STAFF"].includes(session.user.role);
  const isOwningClient = session.user.role === "CLIENT" && session.user.clientId === payment.clientId;
  if (!isStaffSide && !isOwningClient) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  let invoice = payment.invoice;
  if (!invoice) {
    invoice = await prisma.invoice.create({
      data: {
        invoiceNumber: await generateInvoiceNumber(),
        projectId: payment.projectId,
        paymentId: payment.id,
        amount: payment.amount,
      },
    });
  }

  const companySettings = await prisma.companySetting.findUnique({ where: { id: "singleton" } });

  return NextResponse.json({ invoice, payment, companySettings });
}
