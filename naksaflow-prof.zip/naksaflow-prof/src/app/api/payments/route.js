import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { logActivity } from "@/lib/project-helpers";
import { notifyAdmins } from "@/lib/notifications";

const paymentSchema = z.object({
  projectId: z.string().min(1),
  type: z.enum(["CONSULTANCY_FEE", "MUNICIPALITY_FEE", "ADVANCE_PAYMENT", "DUE_PAYMENT"]),
  amount: z.coerce.number().positive(),
  method: z.enum(["CASH", "BANK_TRANSFER", "ESEWA", "KHALTI"]),
  status: z.enum(["PENDING", "PARTIAL", "PAID", "OVERDUE"]).default("PENDING"),
  note: z.string().optional(),
});

export async function GET(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  const type = searchParams.get("type");

  const payments = await prisma.payment.findMany({
    where: {
      ...(status ? { status } : {}),
      ...(type ? { type } : {}),
    },
    include: {
      project: { select: { id: true, projectNumber: true } },
      client: { select: { id: true, fullName: true } },
      invoice: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ payments });
}

export async function POST(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await request.json();
  const parsed = paymentSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const project = await prisma.naksaProject.findUnique({
    where: { id: parsed.data.projectId },
    select: { clientId: true, projectNumber: true },
  });
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const payment = await prisma.payment.create({
    data: {
      projectId: parsed.data.projectId,
      clientId: project.clientId,
      type: parsed.data.type,
      amount: parsed.data.amount,
      method: parsed.data.method,
      status: parsed.data.status,
      note: parsed.data.note || null,
      paidAt: parsed.data.status === "PAID" ? new Date() : null,
    },
    include: {
      project: { select: { id: true, projectNumber: true } },
      client: { select: { id: true, fullName: true } },
    },
  });

  await logActivity({
    userId: session.user.id,
    projectId: payment.projectId,
    action: "created",
    module: "Payment",
    details: `Recorded ${parsed.data.type} of Rs. ${parsed.data.amount} for ${project.projectNumber}`,
  });

  if (parsed.data.status === "PENDING" || parsed.data.status === "OVERDUE") {
    await notifyAdmins({
      projectId: payment.projectId,
      type: "PAYMENT_DUE",
      title: `Payment due — ${project.projectNumber}`,
      message: `Rs. ${parsed.data.amount.toLocaleString("en-IN")} ${parsed.data.type
        .toLowerCase()
        .replaceAll("_", " ")} is outstanding.`,
    });
  }

  return NextResponse.json({ payment }, { status: 201 });
}
