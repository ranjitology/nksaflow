import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PATCH(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Only an admin can update users" }, { status: 403 });
  }

  const { id } = await params;
  const body = await request.json();

  if (id === session.user.id && body.isActive === false) {
    return NextResponse.json({ error: "You can't deactivate your own account" }, { status: 400 });
  }

  const allowed = ["role", "isActive", "phone", "licenseNumber", "name"];
  const data = {};
  for (const key of allowed) {
    if (key in body) data[key] = body[key];
  }

  const user = await prisma.user.update({
    where: { id },
    data,
    select: { id: true, name: true, email: true, role: true, isActive: true },
  });

  return NextResponse.json({ user });
}
