import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { projectSchema } from "@/lib/validations/project";
import { generateProjectNumber, logActivity } from "@/lib/project-helpers";
import { notifyAdmins } from "@/lib/notifications";

export async function GET(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q");
  const stage = searchParams.get("stage");

  const where = {
    ...(stage ? { stage } : {}),
    ...(q
      ? {
          OR: [
            { projectNumber: { contains: q } },
            { kittaNumber: { contains: q } },
            { client: { fullName: { contains: q } } },
            { client: { phone: { contains: q } } },
            { municipality: { name: { contains: q } } },
          ],
        }
      : {}),
  };

  const projects = await prisma.naksaProject.findMany({
    where,
    include: { client: true, municipality: true, engineer: true },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json({ projects });
}

export async function POST(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "ENGINEER", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await request.json();
  const parsed = projectSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const data = parsed.data;
  const projectNumber = await generateProjectNumber();

  const project = await prisma.naksaProject.create({
    data: {
      projectNumber,
      clientId: data.clientId,
      municipalityId: data.municipalityId,
      wardNumber: data.wardNumber,
      kittaNumber: data.kittaNumber,
      landArea: data.landArea,
      landAreaUnit: data.landAreaUnit,
      buildingType: data.buildingType,
      numberOfFloors: data.numberOfFloors,
      estimatedCost: data.estimatedCost,
      engineerId: data.engineerId || null,
      architectId: data.architectId || null,
      surveyorId: data.surveyorId || null,
      startDate: data.startDate ? new Date(data.startDate) : new Date(),
      createdById: session.user.id,
      statusHistory: {
        create: { stage: "NEW_INQUIRY", note: "Project created" },
      },
    },
    include: { client: true, municipality: true },
  });

  await logActivity({
    userId: session.user.id,
    projectId: project.id,
    action: "created",
    module: "Project",
    details: `Created project ${project.projectNumber} for ${project.client.fullName}`,
  });

  await notifyAdmins({
    projectId: project.id,
    type: "PROJECT_CREATED",
    title: `New project — ${project.projectNumber}`,
    message: `${project.client.fullName} was filed with ${project.municipality.name}.`,
  });

  return NextResponse.json({ project }, { status: 201 });
}
