import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/project-helpers";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

const ALLOWED_EXTENSIONS = ["pdf", "dwg", "dxf", "jpg", "jpeg", "png"];
const MAX_SIZE_BYTES = 25 * 1024 * 1024; // 25MB

export async function POST(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;

  const formData = await request.formData();
  const file = formData.get("file");
  const category = formData.get("category") || "OTHER";

  if (!file || typeof file === "string") {
    return NextResponse.json({ error: "No file provided" }, { status: 400 });
  }

  const ext = (file.name.split(".").pop() || "").toLowerCase();
  if (!ALLOWED_EXTENSIONS.includes(ext)) {
    return NextResponse.json(
      { error: `Unsupported file type .${ext}. Allowed: ${ALLOWED_EXTENSIONS.join(", ")}` },
      { status: 400 }
    );
  }
  if (file.size > MAX_SIZE_BYTES) {
    return NextResponse.json({ error: "File exceeds the 25MB limit" }, { status: 400 });
  }

  const uploadDir = path.join(process.cwd(), "public", "uploads", id);
  await mkdir(uploadDir, { recursive: true });

  const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g, "_")}`;
  const filePath = path.join(uploadDir, safeName);
  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(filePath, buffer);

  const document = await prisma.projectDocument.create({
    data: {
      projectId: id,
      category,
      fileName: file.name,
      fileUrl: `/uploads/${id}/${safeName}`,
      fileType: ext,
      fileSize: file.size,
      uploadedById: session.user.id,
    },
  });

  await logActivity({
    userId: session.user.id,
    projectId: id,
    action: "uploaded",
    module: "Document",
    details: `Uploaded ${file.name}`,
  });

  return NextResponse.json({ document }, { status: 201 });
}
