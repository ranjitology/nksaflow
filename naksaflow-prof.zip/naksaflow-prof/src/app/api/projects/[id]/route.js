import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/project-helpers";

export async function GET(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const project = await prisma.naksaProject.findUnique({
    where: { id },
    include: {
      client: true,
      municipality: true,
      engineer: true,
      architect: true,
      surveyor: true,
      statusHistory: { orderBy: { changedAt: "asc" } },
      documents: { orderBy: { createdAt: "desc" } },
      revisions: { orderBy: { revisionNumber: "desc" }, include: { engineer: { select: { name: true } } } },
      siteSurveys: {
        orderBy: { surveyDate: "desc" },
        include: { engineer: { select: { name: true } }, photos: true },
      },
      payments: true,
    },
  });

  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ project });
}

export async function PATCH(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "ENGINEER", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const body = await request.json();

  const allowedFields = [
    "wardNumber",
    "kittaNumber",
    "landArea",
    "landAreaUnit",
    "buildingType",
    "numberOfFloors",
    "estimatedCost",
    "engineerId",
    "architectId",
    "surveyorId",
  ];
  const data = {};
  for (const key of allowedFields) {
    if (key in body) data[key] = body[key];
  }

  const project = await prisma.naksaProject.update({ where: { id }, data });

  await logActivity({
    userId: session.user.id,
    projectId: id,
    action: "updated",
    module: "Project",
    details: "Project details updated",
  });

  return NextResponse.json({ project });
}

export async function DELETE(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.user.role !== "ADMIN") {
    return NextResponse.json({ error: "Only an admin can delete a project" }, { status: 403 });
  }

  const { id } = await params;
  await prisma.naksaProject.delete({ where: { id } });

  await logActivity({
    userId: session.user.id,
    projectId: null,
    action: "deleted",
    module: "Project",
    details: `Deleted project ${id}`,
  });

  return NextResponse.json({ success: true });
}
