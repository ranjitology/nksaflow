import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/project-helpers";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

const ALLOWED_EXTENSIONS = ["jpg", "jpeg", "png", "pdf"];

export async function GET(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const surveys = await prisma.siteSurvey.findMany({
    where: { projectId: id },
    include: { engineer: { select: { name: true } }, photos: true },
    orderBy: { surveyDate: "desc" },
  });

  return NextResponse.json({ surveys });
}

export async function POST(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "ENGINEER", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const formData = await request.formData();

  const surveyDate = formData.get("surveyDate");
  const gpsLatitude = formData.get("gpsLatitude");
  const gpsLongitude = formData.get("gpsLongitude");
  const siteNotes = formData.get("siteNotes");
  const engineerId = formData.get("engineerId") || session.user.id;

  if (!surveyDate) {
    return NextResponse.json({ error: "Survey date is required" }, { status: 400 });
  }

  const survey = await prisma.siteSurvey.create({
    data: {
      projectId: id,
      surveyDate: new Date(surveyDate),
      gpsLatitude: gpsLatitude ? parseFloat(gpsLatitude) : null,
      gpsLongitude: gpsLongitude ? parseFloat(gpsLongitude) : null,
      siteNotes: siteNotes || null,
      engineerId,
    },
  });

  // Handle any number of files uploaded under the "photos" field.
  const files = formData.getAll("photos").filter((f) => typeof f !== "string" && f.size > 0);
  if (files.length > 0) {
    const uploadDir = path.join(process.cwd(), "public", "uploads", id);
    await mkdir(uploadDir, { recursive: true });

    for (const file of files) {
      const ext = (file.name.split(".").pop() || "").toLowerCase();
      if (!ALLOWED_EXTENSIONS.includes(ext)) continue;

      const safeName = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g, "_")}`;
      const buffer = Buffer.from(await file.arrayBuffer());
      await writeFile(path.join(uploadDir, safeName), buffer);

      await prisma.projectDocument.create({
        data: {
          projectId: id,
          category: "SITE_PHOTO",
          fileName: file.name,
          fileUrl: `/uploads/${id}/${safeName}`,
          fileType: ext,
          fileSize: file.size,
          uploadedById: session.user.id,
          siteSurveyId: survey.id,
        },
      });
    }
  }

  await logActivity({
    userId: session.user.id,
    projectId: id,
    action: "created",
    module: "SiteSurvey",
    details: `Recorded site survey on ${surveyDate}`,
  });

  const fullSurvey = await prisma.siteSurvey.findUnique({
    where: { id: survey.id },
    include: { engineer: { select: { name: true } }, photos: true },
  });

  return NextResponse.json({ survey: fullSurvey }, { status: 201 });
}
