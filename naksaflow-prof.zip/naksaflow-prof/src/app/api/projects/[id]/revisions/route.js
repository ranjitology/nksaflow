import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/project-helpers";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

const ALLOWED_EXTENSIONS = ["pdf", "dwg", "dxf", "jpg", "jpeg", "png"];

export async function GET(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const revisions = await prisma.drawingRevision.findMany({
    where: { projectId: id },
    include: { engineer: { select: { name: true } } },
    orderBy: { revisionNumber: "desc" },
  });

  return NextResponse.json({ revisions });
}

export async function POST(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "ENGINEER", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const formData = await request.formData();

  const revisionReason = formData.get("revisionReason");
  const engineerNotes = formData.get("engineerNotes");
  const revisionDate = formData.get("revisionDate") || new Date().toISOString();

  if (!revisionReason) {
    return NextResponse.json({ error: "Revision reason is required" }, { status: 400 });
  }

  const lastRevision = await prisma.drawingRevision.findFirst({
    where: { projectId: id },
    orderBy: { revisionNumber: "desc" },
  });
  const revisionNumber = (lastRevision?.revisionNumber || 0) + 1;

  let fileUrl = null;
  const file = formData.get("file");
  if (file && typeof file !== "string" && file.size > 0) {
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return NextResponse.json({ error: `Unsupported file type .${ext}` }, { status: 400 });
    }
    const uploadDir = path.join(process.cwd(), "public", "uploads", id);
    await mkdir(uploadDir, { recursive: true });
    const safeName = `rev${revisionNumber}-${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.\-_]/g, "_")}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(path.join(uploadDir, safeName), buffer);
    fileUrl = `/uploads/${id}/${safeName}`;
  }

  const revision = await prisma.drawingRevision.create({
    data: {
      projectId: id,
      revisionNumber,
      revisionDate: new Date(revisionDate),
      revisionReason,
      engineerNotes: engineerNotes || null,
      fileUrl,
      engineerId: session.user.id,
    },
    include: { engineer: { select: { name: true } } },
  });

  await logActivity({
    userId: session.user.id,
    projectId: id,
    action: "created",
    module: "DrawingRevision",
    details: `Revision ${revisionNumber}: ${revisionReason}`,
  });

  return NextResponse.json({ revision }, { status: 201 });
}
