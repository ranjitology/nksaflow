import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { statusUpdateSchema } from "@/lib/validations/project";
import { transitionProjectStage } from "@/lib/project-helpers";

export async function POST(request, { params }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "ENGINEER", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const body = await request.json();
  const parsed = statusUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const project = await transitionProjectStage({
    projectId: id,
    stage: parsed.data.stage,
    note: parsed.data.note,
    userId: session.user.id,
  });

  return NextResponse.json({ project });
}
