import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";
import { logActivity } from "@/lib/project-helpers";

const clientSchema = z.object({
  fullName: z.string().min(1, "Name is required"),
  phone: z.string().min(1, "Phone is required"),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  citizenshipNumber: z.string().optional(),
  panNumber: z.string().optional(),
  municipalityId: z.string().optional(),
  wardNumber: z.string().optional(),
});

export async function GET(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q");

  const clients = await prisma.client.findMany({
    where: q
      ? { OR: [{ fullName: { contains: q } }, { phone: { contains: q } }] }
      : undefined,
    include: { municipality: true, _count: { select: { projects: true } } },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ clients });
}

export async function POST(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!["ADMIN", "STAFF"].includes(session.user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await request.json();
  const parsed = clientSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const client = await prisma.client.create({ data: parsed.data });

  await logActivity({
    userId: session.user.id,
    action: "created",
    module: "Client",
    details: `Added client ${client.fullName}`,
  });

  return NextResponse.json({ client }, { status: 201 });
}
