import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") || "").trim();

  if (!q || q.length < 2) {
    return NextResponse.json({ projects: [], clients: [], municipalities: [] });
  }

  const [projects, clients, municipalities] = await Promise.all([
    prisma.naksaProject.findMany({
      where: {
        OR: [
          { projectNumber: { contains: q } },
          { kittaNumber: { contains: q } },
          { client: { fullName: { contains: q } } },
          { client: { phone: { contains: q } } },
          { municipality: { name: { contains: q } } },
        ],
      },
      include: { client: true, municipality: true },
      orderBy: { updatedAt: "desc" },
      take: 6,
    }),
    prisma.client.findMany({
      where: { OR: [{ fullName: { contains: q } }, { phone: { contains: q } }] },
      take: 5,
    }),
    prisma.municipality.findMany({
      where: { name: { contains: q } },
      take: 5,
    }),
  ]);

  return NextResponse.json({ projects, clients, municipalities });
}
